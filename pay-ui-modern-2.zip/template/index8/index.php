﻿<?php
if(!defined('IN_CRONLITE'))exit();
?>
<!DOCTYPE html>
<!--[if IE 9]>
<html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!-->
<html lang="zh-cn">
<!--<![endif]-->
<head>
    <meta charset="utf-8">
    <title><?php echo $conf['title']?></title>
	<meta name="keywords" content="<?php echo $conf['keywords']?>">
	<meta name="description" content="<?php echo $conf['description']?>">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
    <link rel="stylesheet" type="text/css" href="<?php echo $cdnpublic?>twitter-bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $cdnpublic?>OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo STATIC_ROOT?>css/animations.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo STATIC_ROOT?>css/style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo STATIC_ROOT?>css/responsive.css">
    <!--[if lt IE 9]>
	  <script src="<?php echo $cdnpublic?>html5shiv/3.7.3/html5shiv.min.js"></script>
	  <script src="<?php echo $cdnpublic?>respond.js/1.4.2/respond.min.js"></script>
	<![endif]-->
	<style>.section {padding: 25px 0;color: #666666;}</style>
<link rel="stylesheet" href="<?php echo STATIC_ROOT?>css/theme.css">
<link rel="stylesheet" href="<?php echo $cdnpublic?>font-awesome/4.7.0/css/font-awesome.min.css" />
</head>
<body>
<!-- ===== 统一 Header（浅蓝科技风） ===== -->
<div class="hp-hd" id="hpHd">
  <div class="hp-hd-in">
    <a class="hp-logo" href="/"><img src="/assets/img/logo.png" alt=""></a>
    <button type="button" class="hp-burger" id="hpBurger" aria-label="展开菜单"><i class="fa fa-bars"></i></button>
    <nav class="hp-nav" id="hpNav">
      <a href="/">首页</a>
      <a href="/doc/index.html">开发文档</a>
      <?php if(!empty($conf['test_open'])){ ?><a href="/user/test.php">支付测试</a><?php } ?>
      <?php if(!empty($conf['appurl'])){ ?><a href="<?php echo $conf['appurl']?>">APP下载</a><?php } ?>
    </nav>
    <div class="hp-hd-act">
      <a class="hp-btn-ghost" href="/user/">商户登录</a>
      <a class="hp-btn-main" href="/user/reg.php">商户注册</a>
    </div>
  </div>
</div>
<script>
(function(){
  var b=document.getElementById('hpBurger'), h=document.getElementById('hpNav');
  if(b&&h) b.addEventListener('click',function(){ h.classList.toggle('show'); });
})();
</script>

<div class="wrapper">
    <header>
        <div class="container">
            <div class="row">
                <div class="col-md-2">
                    <div class="logo"><a href=""><img src="assets/img/logo.png" alt=""></a></div>
                </div>
                <div class="col-md-7">
                    <ul class="menu">
                        <li><a href="/">网站首页</a></li>
                        <li><a href="/user/test.php" target="_blank">demo测试</a></li>
						<li><a href="/doc.html" target="_blank">开发文档</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <div class="button-header">
                        <a href="/user/" class="custom-btn login">商户登录</a>
                        <a href="/user/reg.php" class="custom-btn">注册商户</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="mobile-block">
            <div class="logo-mobile"><a href=""><img src="assets/img/logo.png" alt=""></a></div>
            <a href="#" class="mobile-menu-btn"><span></span></a>
            <div class="mobile-menu">
                <div class="inside">
                    <div class="logo">
                        <a href=""><img src="assets/img/logo.png" alt="""></a>
                    </div>
                    <ul class="menu panel-group" id="accordion" aria-multiselectable="true">
                        <li><a href="/">网站首页</a></li>
                        <li><a href="/user/test.php">demo测试</a></li>
						<li><a href="/doc.html">开发文档</a></li>
                    </ul>
                    <div class="button-header">
                        <a href="/user/" class="custom-btn login">商户登录</a>
                        <a href="/user/reg.php" class="custom-btn">注册商户</a>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div class="base-slider owl-carousel owl-theme bg-gray">
        <div class="item">
            <img src="<?php echo STATIC_ROOT?>picture/bg-test.png" alt=""">
            <div class="inside">
                <h2><?php echo $conf['sitename']?> - 为创业者而生</h2>
                <p>专注于提供安全、高效、严谨、便捷的订单数据服务！</p>
                <a href="/user/login.php" class="custom-btn">立即登录</a>
            </div>
        </div>
    </div>
    <section class="bg-gray">
        <div class="container">
            <div class="why-choose animatedParent">
                <h2 class="title-head">全天候无人值守 7X24小时高效运转</h2>
                <div class="row">
                    <div class="col-md-4 col-xs-12 animated bounceInUp delay-250 go">
                        <div class="inside">
                            <img src="<?php echo STATIC_ROOT?>picture/optimised.svg" alt=""">
                            <a href="">极速响应</a>
                            <p>付款后立即回调,无等待,流程超顺畅</p>
                            <a href="/user/reg.php" class="read-more">加入我们<img src="<?php echo STATIC_ROOT?>picture/right.png" alt="""></a>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12 animated bounceInUp delay-500 go">
                        <div class="inside">
                            <img src="<?php echo STATIC_ROOT?>picture/powerfull.svg" alt=""">
                            <a href="">资金直达</a>
                            <p>系统收到交易消息后自动将余额提现</p>
                            <a href="/user/reg.php" class="read-more">加入我们<img src="<?php echo STATIC_ROOT?>picture/right.png" alt="""></a>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12 animated bounceInUp delay-750 go">
                        <div class="inside">
                            <img src="<?php echo STATIC_ROOT?>picture/website.svg" alt=""">
                            <a href="">账户安全</a>
                            <p>绑定后无法更改,防止他人修改结算账户</p>
                            <a href="/user/reg.php" class="read-more">加入我们<img src="<?php echo STATIC_ROOT?>picture/right.png" alt="""></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
	<div class="section section-pricing">
<div class="title-block">
<div style="text-align:center;">
平台合作伙伴
</div>
<center>
<img style="FILTER: gray()" src="<?php echo STATIC_ROOT?>picture/aliyun.png" width="85">
<img style="FILTER: gray()" src="<?php echo STATIC_ROOT?>picture/qqpay.png" width="85">
<img style="FILTER: gray()" src="<?php echo STATIC_ROOT?>picture/wxpay.png" width="85">
<img style="FILTER: gray()" src="<?php echo STATIC_ROOT?>picture/tenpay.png" width="85">
</center>
</div>
</div>
</div>
</div>
</div>
</div>
    <footer>
        <div class="container">
            <div class="copyright text-center">
			<p style="font-style:oblique;font-size:14px;color:#FFF"><?php echo $conf['sitename']?>&nbsp;&nbsp;&copy;&nbsp;<?php echo date("Y")?>&nbsp;All Rights Reserved.<br/><?php echo $conf['footer']?></p>
            </div>
        </div>
    </footer>
</div>
<script type="text/javascript" src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo $cdnpublic?>OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script src="<?php echo STATIC_ROOT?>js/main.js"></script>
<script type="text/javascript">
    $(function () {
        $("header").addClass('transparent');
    });
</script>
<!-- ===== 统一 Footer（浅蓝科技风） ===== -->
<div class="hp-ft">
  <div class="hp-ft-in">
    <div class="hp-ft-brand">
      <div class="hp-ft-lg"><img src="/assets/img/logo.png" alt=""><span><?php if(!empty($conf['sitename'])) echo $conf['sitename']; ?></span></div>
      <p class="hp-ft-desc">专业的收银系统，为企业提供收款、付款、结算、营销的一体化支付技术方案。</p>
      <ul class="hp-ft-ct">
        <?php if(!empty($conf['kfqq'])){ ?><li><i class="fa fa-qq"></i> <a href="https://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq']?>&Site=pay&Menu=yes" target="_blank" rel="noreferrer"><?php echo $conf['kfqq']?></a></li><?php } ?>
        <?php if(!empty($conf['email'])){ ?><li><i class="fa fa-envelope"></i> <a href="mailto:<?php echo $conf['email']?>"><?php echo $conf['email']?></a></li><?php } ?>
        <li><i class="fa fa-map-marker"></i> 专业的支付技术服务平台</li>
      </ul>
    </div>
    <div class="hp-ft-links">
      <div class="hp-ft-col">
        <h5>产品</h5>
        <a href="/doc/index.html">开发文档</a>
        <a href="/user/reg.php">商户注册</a>
      </div>
      <div class="hp-ft-col">
        <h5>服务</h5>
        <a href="/user/">商户登录</a>
        <a href="/user/order.php">订单查询</a>
      </div>
      <div class="hp-ft-col">
        <h5>关于</h5>
        <a href="/">平台首页</a>
        <?php if(!empty($conf['test_open'])){ ?><a href="/user/test.php">支付测试</a><?php } ?>
      </div>
      <div class="hp-ft-col">
        <h5>扫码关注</h5>
        <div class="hp-ft-qr"><img src="/assets/img/weixin.gif" alt=""></div>
      </div>
    </div>
  </div>
  <div class="hp-ft-btm">
    <?php if(!empty($conf['sitename'])) echo $conf['sitename']; ?>&nbsp;&copy;&nbsp;<?php echo date("Y")?>&nbsp;All Rights Reserved.<?php if(!empty($conf['footer'])) echo '&nbsp;&nbsp;'.$conf['footer']; ?>
  </div>
</div>
</body>
</html>