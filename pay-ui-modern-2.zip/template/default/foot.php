<?php
if(!defined('IN_CRONLITE'))exit();
?>

<div class="address">
<footer>
<div class="container">
<div class="row">
<div class="col-xs-12 col-md-8 col-lg-9">
<ul class="porduct">
<h4>产品</h4>
<li><a href="agreement.html" target="_blank">服务条款</a></li>
<li><a href="doc.html" target="_blank">开发文档</a></li>
</ul>
<ul class="price">
<h4>关于我们</h4>
<li><?php echo $conf['sitename']?>是<?php echo $conf['orgname']?>旗下的免签约支付产品</li>
</ul>
<ul class="about"style="width: 40%;padding-left: 22px;">
<h4>联系我们</h4>
<li><strong>QQ:</strong><a href="https://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq']?>&Site=pay&Menu=yes" target="_blank"><?php echo $conf['kfqq']?></a></li>
<li><strong>Email:</strong><a href="mailto:<?php echo $conf['email']?>"><?php echo $conf['email']?></a></li>
</ul>
</div>

</div>
<div class="xinxi">
<p><?php echo $conf['sitename']?>&nbsp;&nbsp;&copy;<?php echo date("Y")?>&nbsp;All Rights Reserved.&nbsp;&nbsp;<?php echo $conf['footer']?></p>
</div>
<script type="text/javascript">
        if('ontouchend' in document.body && $(window).width() < 996){
          $('.col-xs-12 .h2').css('text-align','center');
        }
      </script>
</div>
</footer>
</div>
</div>
<!-- ===== 统一 Footer（浅蓝科技风） ===== -->
<footer class="hp-ft">
  <div class="hp-ft-in">
    <div class="hp-ft-brand">
      <div class="hp-ft-lg"><img src="/assets/img/logo.png" alt=""><span><?php if(!empty($conf['sitename'])) echo $conf['sitename']; ?></span></div>
      <p class="hp-ft-desc">专业的收银系统，为企业提供收款、付款、结算、营销的一体化支付技术方案。</p>
      <ul class="hp-ft-ct">
        <?php if(!empty($conf['kfqq'])){ ?><li><i class="fa fa-qq"></i> <a href="https://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq']?>&Site=pay&Menu=yes" target="_blank" rel="noreferrer"><?php echo $conf['kfqq']?></a></li><?php } ?>
        <?php if(!empty($conf['email'])){ ?><li><i class="fa fa-envelope"></i> <a href="mailto:<?php echo $conf['email']?>"><?php echo $conf['email']?></a></li><?php } ?>
        <li><i class="fa fa-map-marker"></i> 专业的支付技术服务平台</li>
      </ul>
    </div>
    <div class="hp-ft-links">
      <div class="hp-ft-col">
        <h5>产品</h5>
        <a href="/doc/index.html">开发文档</a>
        <a href="/user/reg.php">商户注册</a>
      </div>
      <div class="hp-ft-col">
        <h5>服务</h5>
        <a href="/user/">商户登录</a>
        <a href="/user/order.php">订单查询</a>
      </div>
      <div class="hp-ft-col">
        <h5>关于</h5>
        <a href="/">平台首页</a>
        <?php if(!empty($conf['test_open'])){ ?><a href="/user/test.php">支付测试</a><?php } ?>
      </div>
      <div class="hp-ft-col">
        <h5>扫码关注</h5>
        <div class="hp-ft-qr"><img src="/assets/img/weixin.gif" alt=""></div>
      </div>
    </div>
  </div>
  <div class="hp-ft-btm">
    <?php if(!empty($conf['sitename'])) echo $conf['sitename']; ?>&nbsp;&copy;&nbsp;<?php echo date("Y")?>&nbsp;All Rights Reserved.<?php if(!empty($conf['footer'])) echo '&nbsp;&nbsp;'.$conf['footer']; ?>
  </div>
</footer>
</body>
</html> 