<?php
if(!defined('IN_CRONLITE'))exit();
?>
<!-- Footer -->
<footer class="hp-footer">
	<div class="hp-wrap hp-footer-top">
		<div class="hp-footer-brand">
			<div class="hp-footer-logo">
				<img src="/assets/img/logo.png" alt="<?php echo $conf['sitename']?>" />
				<span><?php echo $conf['sitename']?></span>
			</div>
			<p class="hp-footer-desc">专业的收银系统，为企业提供收款、付款、结算、营销的一体化支付技术方案。</p>
			<ul class="hp-footer-contact">
				<li><i class="fa fa-qq"></i> <a href="https://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq']?>&Site=pay&Menu=yes" target="_blank"><?php echo $conf['kfqq']?></a></li>
				<li><i class="fa fa-envelope"></i> <a href="mailto:<?php echo $conf['email']?>"><?php echo $conf['email']?></a></li>
				<li><i class="fa fa-map-marker"></i> 深圳市龙岗区龙岗街道龙岗大道4005号和创大厦306</li>
			</ul>
		</div>
		<div class="hp-footer-links">
			<div class="hp-fcol">
				<h5>关于我们</h5>
				<p><a href="aboutUs.html">公司信息</a></p>
				<p><a href="aboutUs.html">联系我们</a></p>
				<p><a href="aboutUs.html">加入我们</a></p>
			</div>
			<div class="hp-fcol">
				<h5>产品</h5>
				<p><a target="_blank" href="/doc.html">开发文档</a></p>
				<p><a target="_blank" href="/SDK.zip">SDK下载</a></p>
			</div>
			<div class="hp-fcol">
				<h5>其它</h5>
				<p><a href="aboutUs.html">合作伙伴</a></p>
				<p><a href="agreement.html">用户协议</a></p>
				<p><a href="produceIntroduce.html">功能介绍</a></p>
			</div>
			<div class="hp-fcol hp-fcol-qr">
				<h5>扫码关注</h5>
				<div class="hp-qr"><img src="/assets/img/weixin.gif" alt="关注<?php echo $conf['sitename']?>" /></div>
				<p class="hp-qr-txt">关注<?php echo $conf['sitename']?></p>
			</div>
		</div>
	</div>
	<div class="hp-footer-bottom">
		<div class="hp-wrap">
			<p><?php echo $conf['sitename']?>&nbsp;&nbsp;&copy;<?php echo date("Y")?>&nbsp;All Rights Reserved.&nbsp;&nbsp;<?php echo $conf['footer']?></p>
		</div>
	</div>
</footer>
</div>
</body>
</html>
