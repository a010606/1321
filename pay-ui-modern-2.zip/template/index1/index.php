<?php
if(!defined('IN_CRONLITE'))exit();
require INDEX_ROOT.'head.php';
?>
<!-- ============ Hero ============ -->
<section class="hp-hero">
	<div class="hp-grid-bg"></div>
	<div class="hp-hero-glow hp-glow-1"></div>
	<div class="hp-hero-glow hp-glow-2"></div>
	<div class="hp-wrap hp-hero-inner">
		<div class="hp-hero-txt">
			<span class="hp-tag"><i class="fa fa-cube"></i> 专业支付解决方案</span>
			<h1>专业的收银系统</h1>
			<p class="hp-lead">全面集成主流支付渠道，为企业提供解决<span>收款</span><span>付款</span><span>结算</span><span>营销</span>等问题的技术方案</p>
			<p class="hp-sub">提供企业统一管理电子钱包的技术方案</p>
			<div class="hp-hero-btns">
				<a href="/user/reg.php" class="hp-btn hp-btn-main" target="_blank">注册使用</a>
				<a href="/user/" class="hp-btn hp-btn-ghost">商户登录</a>
			</div>
		</div>
		<div class="hp-hero-img">
			<div class="hp-hero-ring"></div>
			<img src="<?php echo STATIC_ROOT?>picture/phone.png" alt="" />
		</div>
	</div>
</section>

<!-- ============ 数据条 ============ -->
<section class="hp-stats">
	<div class="hp-wrap hp-stats-grid">
		<div class="hp-stat">
			<b>7×24</b>
			<span>全天候服务响应</span>
		</div>
		<div class="hp-stat">
			<b>99.99%</b>
			<span>系统可用性保障</span>
		</div>
		<div class="hp-stat">
			<b>5+</b>
			<span>主流支付渠道接入</span>
		</div>
		<div class="hp-stat">
			<b>HTTPS</b>
			<span>全链路传输加密</span>
		</div>
	</div>
</section>

<!-- ============ 核心能力（云支付 / 云钱包 / 云结算） ============ -->
<section class="hp-sec">
	<div class="hp-wrap">
		<div class="hp-sec-head">
			<span class="hp-eyebrow">CORE CAPABILITIES</span>
			<h2>核心能力</h2>
			<p>覆盖收款、账户、结算全链路的支付基础设施</p>
		</div>
		<div class="hp-cards">
			<div class="hp-card">
				<div class="hp-card-img">
					<img src="<?php echo STATIC_ROOT?>picture/use01.png" alt="" />
				</div>
				<div class="hp-card-body">
					<h3>云支付</h3>
					<span class="hp-card-sub">全支付场景及渠道覆盖</span>
					<p>支持支付宝、微信、银联、QQ钱包、快钱等主流支付渠道，让您拥有PC网页支付、扫码支付、手机APP支付、移动HTML5支付、微信公众号支付。</p>
				</div>
			</div>
			<div class="hp-card">
				<div class="hp-card-img">
					<img src="<?php echo STATIC_ROOT?>picture/use02.png" alt="" />
				</div>
				<div class="hp-card-body">
					<h3>云钱包</h3>
					<span class="hp-card-sub">统一虚拟账户体系</span>
					<p>企业通过<?php echo $conf['sitename']?>为用户提供统一虚拟账户，提升用户支付体验，为拓展增值服务提供基础</p>
				</div>
			</div>
			<div class="hp-card">
				<div class="hp-card-img">
					<img src="<?php echo STATIC_ROOT?>picture/use03.png" alt="" />
				</div>
				<div class="hp-card-body">
					<h3>云结算</h3>
					<span class="hp-card-sub">自动化资金结算</span>
					<p>通过简单的页面配置，可以替代复杂繁琐的人工资金结算业务，提高业务实时性，降低错误</p>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- ============ 我们的优势 ============ -->
<section class="hp-sec hp-sec-alt">
	<div class="hp-wrap">
		<div class="hp-sec-head">
			<span class="hp-eyebrow">WHY CHOOSE US</span>
			<h2>我们的优势</h2>
			<p>从接入到运营，让每一笔交易都更省心</p>
		</div>
		<div class="hp-adv-grid">
			<div class="hp-adv">
				<div class="hp-adv-ic"><i class="fa fa-code"></i></div>
				<h4>降低研发成本</h4>
				<p>简单快速的接入方式，缩短开发周期，实现快速上线。</p>
			</div>
			<div class="hp-adv">
				<div class="hp-adv-ic"><i class="fa fa-calculator"></i></div>
				<h4>轻松结算对账</h4>
				<p>降低财务人员在结算方面投入的时间和精力，客服人员也可以轻松查看账户明细</p>
			</div>
			<div class="hp-adv">
				<div class="hp-adv-ic"><i class="fa fa-plug"></i></div>
				<h4>全面开放API</h4>
				<p>让企业更加自主的使用<?php echo $conf['sitename']?>相关服务</p>
			</div>
			<div class="hp-adv">
				<div class="hp-adv-ic"><i class="fa fa-shield"></i></div>
				<h4>安全稳定高效</h4>
				<p>HTTPS传输加密，REST API调用数字签名验证，ACL权限控制，严格保护客户数据的安全和隐私</p>
			</div>
		</div>
	</div>
</section>

<!-- ============ 底部 CTA ============ -->
<section class="hp-cta">
	<div class="hp-cta-glow"></div>
	<div class="hp-wrap">
		<h2>想要了解更多</h2>
		<div class="hp-cta-grid">
			<a href="produceIntroduce.html" class="hp-cta-card">
				<div class="hp-cta-ic"><i class="fa fa-chain"></i></div>
				<h4>了解更多</h4>
				<p>你也许还有更多疑问，我们的帮助中心会为您提供答案</p>
			</a>
			<a href="doc.html" class="hp-cta-card">
				<div class="hp-cta-ic"><i class="fa fa-credit-card"></i></div>
				<h4>开发文档</h4>
				<p>获取对接我们的API接口以及SDK</p>
			</a>
			<a href="https://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq']?>&Site=pay&Menu=yes" target="_blank" class="hp-cta-card">
				<div class="hp-cta-ic"><i class="fa fa-users"></i></div>
				<h4>商务合作</h4>
				<p>如果有什么需求或者意见，我们期待您的联系。</p>
			</a>
		</div>
		<div class="hp-cta-bottom">
			<a href="/user/reg.php" class="hp-btn hp-btn-light" target="_blank">注册成为会员</a>
		</div>
	</div>
</section>
<?php require INDEX_ROOT.'foot.php';?>
