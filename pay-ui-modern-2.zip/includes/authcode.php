<?php
define('authcode','114affb8994f7b2e7bda3ac54dd24814');

?>