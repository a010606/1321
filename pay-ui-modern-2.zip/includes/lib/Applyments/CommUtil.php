<?php
namespace lib\Applyments;

use Exception;

class CommUtil
{
    private static $typeList = [
        'Alipay' => [
            'name' => '支付宝服务商',
            'pay_plugin' => 'alipaysl',
            'icon' => 'alipay.ico',
        ],
        'AlipayDirect' => [
            'name' => '支付宝直付通',
            'pay_plugin' => 'alipayd',
            'icon' => 'alipay.ico',
        ],
        'Wxpay' => [
            'name' => '微信支付服务商',
            'pay_plugin' => 'wxpaynp',
            'icon' => 'wechat.ico',
        ],
        'WxpayEC' => [
            'name' => '微信支付收付通',
            'pay_plugin' => 'wxpaynp',
            'icon' => 'wechat.ico',
        ],
        'Kuaiqian' => [
            'name' => '快钱支付',
            'pay_plugin' => 'kuaiqian',
            'icon' => 'kuaiqian.ico',
        ],
        'Hnapay' => [
            'name' => '新生易聚合支付',
            'pay_plugin' => 'xsy',
            'icon' => 'hnapay.ico',
        ],
        'Hnapayx' => [
            'name' => '新生支付',
            'pay_plugin' => 'hnapay',
            'icon' => 'hnapay.ico',
        ],
        'Huolian' => [
            'name' => '火脸支付',
            'pay_plugin' => 'huolian',
            'icon' => 'huolian.png',
        ],
        'Yseqt' => [
            'name' => '银盛e企通',
            'pay_plugin' => 'yseqt',
            'icon' => 'ysepay.png',
        ],
        'Yswallet' => [
            'name' => '银盛钱包',
            'pay_plugin' => 'yseqt',
            'icon' => 'ysepay.png',
        ],
        'Yeepay' => [
            'name' => '易宝支付',
            'pay_plugin' => 'yeepay',
            'icon' => 'yeepay.ico',
        ],
        'Huifu' => [
            'name' => '汇付斗拱平台',
            'pay_plugin' => 'huifu',
            'icon' => 'huifu.ico',
        ],
        'Haipay' => [
            'name' => '海科聚合支付',
            'pay_plugin' => 'haipay',
            'icon' => 'haipay.ico',
        ],
        'Dinpay' => [
            'name' => '智付',
            'pay_plugin' => 'dinpay',
            'icon' => 'dinpay.png',
        ],
        'Fuiou' => [
            'name' => '富友支付',
            'pay_plugin' => 'fuiou2',
            'icon' => 'fuiou.ico',
        ],
        'Duolabao' => [
            'name' => '哆啦宝',
            'pay_plugin' => 'duolabao',
            'icon' => 'duolabao.ico',
        ],
        'Lakala' => [
            'name' => '拉卡拉',
            'pay_plugin' => 'lakala',
            'icon' => 'lakala.png',
        ],
        'Sumapay' => [
            'name' => '丰付企账宝',
            'pay_plugin' => 'sumapay2',
            'icon' => 'sumapay.ico',
        ],
        'Yinyingtong' => [
            'name' => '银盈通支付',
            'pay_plugin' => 'yinyingtong',
            'icon' => 'yinyingtong.png',
        ],
        'Ysepay' => [
            'name' => '银盛支付',
            'pay_plugin' => 'ysepay',
            'icon' => 'ysepay.png',
        ],
        'Hxtpay' => [
            'name' => '恒信通易付通',
            'pay_plugin' => 'hxtpay',
            'icon' => 'hxtpay.ico',
        ],
        'Heepay' => [
            'name' => '汇付宝',
            'pay_plugin' => 'heepay',
            'icon' => 'heepay.ico',
        ],
        'Baocaitong' => [
            'name' => '宝财通',
            'pay_plugin' => 'baofu',
            'icon' => 'baofu.ico',
        ],
        'Epaylinks' => [
            'name' => '易票联',
            'pay_plugin' => 'epaylinks',
            'icon' => 'epaylinks.ico',
        ],
        'Kunpeng' => [
            'name' => '鲲鹏支付',
            'pay_plugin' => 'kunpeng',
            'icon' => 'kunpeng.ico',
        ],
        'Customize' => [
            'name' => '自定义进件',
            'pay_plugin' => '',
            'icon' => 'default.ico',
        ],
    ];

    private static $formType = ['view'=>'查看商户详情', 'create'=>'新增商户进件', 'modify'=>'修改商户信息', 'settlement'=>'修改结算账户', 'upgrade'=>'商户限额升级', 'config'=>'系统配置', 'cancel'=>'申请注销商户', 'setmchid'=>'设置应用授权token', 'setkey'=>'设置商户自定义信息', 'report'=>'提交商户报备', 'withdraw'=>'申请提现'];

    public static function getTypeList()
    {
        return self::$typeList;
    }

    public static function getModel($cid){
        global $DB, $conf;
        $applychannel = $DB->find('applychannel', '*', ['id'=>$cid]);
        if(!$applychannel) return false;
        $channel = \lib\Channel::get($applychannel['channel']);
        if(!$channel) return false;
        if($applychannel['price'] > 0 && $conf['applyments_free'] == 1) $applychannel['price'] = 0;

        $type = $applychannel['type'];
        $classname = '\\lib\\Applyments\\'.$type.'\\'.$type;
        if (class_exists($classname)) {
            $x = new $classname($applychannel, $channel);
            $x->type = $type;
            $x->plugin = $channel['plugin'];
            return $x;
        }else{
            return false;
        }
    }

    public static function getModel2($channel){
        global $DB;
        $applychannel = $DB->find('applychannel', '*', ['channel'=>$channel['id']]);
        if(!$applychannel) return false;

        $type = $applychannel['type'];
        $classname = '\\lib\\Applyments\\'.$type.'\\'.$type;
        if (class_exists($classname)) {
            return new $classname($applychannel, $channel);
        }else{
            return false;
        }
    }

    public static function getOperation($type, $row){
        $classname = '\\lib\\Applyments\\'.$type.'\\'.$type;
        if (class_exists($classname)) {
            return $classname::getOperation($row);
        }else{
            return [];
        }
    }

    //证照识别
    public static function imageRecognize($type, $file_path){
        global $conf;
        $service = \lib\ocr\OcrFactory::create($conf['ocr_type'] ?? 'aliyun');
        $result = null;
        if($type == 'idcard'){
            $result = $service->idcard($file_path);
        }elseif($type == 'idcard_back'){
            $result = $service->idcard_back($file_path);
        }elseif($type == 'bankcard'){
            $result = $service->bank_card($file_path);
        }elseif($type == 'business'){
            $result = $service->business_license($file_path);
        }elseif($type == 'bankaccount'){
            $result = $service->bank_account_license($file_path);
        }
        return $result;
    }

    public static function getFormTitle($action){
        if(!isset(self::$formType[$action]))return '自定义表单';
        return self::$formType[$action];
    }

    public static function payForMerchant($id, $uid, $money){
        global $DB, $conf;
        $userrow = $DB->find('user', 'upid,money', ['uid'=>$uid]);
        if($userrow['money'] >= $money){
            changeUserMoney($uid, $money, false, '新增商户进件');
            $DB->update('applymerchant', ['paid'=>1], ['id'=>$id]);
            
            if($userrow['upid'] > 0){
                $upgid = $DB->findColumn('user', 'gid', ['uid'=>$userrow['upid']]);
                $groupconfig = getGroupConfig($upgid);
                $conf_n = array_merge($conf, $groupconfig);
                if($conf_n['invite_open'] == 1 && $conf_n['invite_apply_rate'] > 0){
                    $invite_money = round($money * $conf_n['invite_apply_rate'] / 100, 2);
                    if($invite_money > 0){
                        changeUserMoney($userrow['upid'], $invite_money, true, '邀请商户进件');
                    }
                }
            }
            return true;
        }
        return false;
    }

    public static function getBankBranchList($bank_code, $city_code){
        global $siteurl;
        $url = 'https://api.cccyun.cc/bankbranch.php?bank_code='.$bank_code.'&city_code='.$city_code;
        $response = get_curl($url, 0, $siteurl);
        $result = json_decode($response, true);
        if(isset($result['code']) && $result['code'] == 0){
            return $result['data'];
        }else{
            throw new \Exception($result['msg']);
        }
    }

}