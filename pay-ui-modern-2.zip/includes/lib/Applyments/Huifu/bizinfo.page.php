<?php
if(!defined('IN_CRONLITE'))exit();?>
<style>tbody tr>td:nth-child(1){width:180px}</style>
<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">查看商户业务开通状态<span class="pull-right"><a class="btn btn-default btn-xs" href="./applyments_form.php?type=page&action=bizinfo&id=<?php echo $row['id']?>">刷新</a></span></h3></div>
<div class="panel-body">

<?php if(isset($data['ali'])){?> 
<table class="table table-hover table-bordered">
	<tbody>
		<tr><td colspan="2"><strong style="font-size:large">支付宝支付</strong></td></tr>
		<tr><td><b>支付宝报备状态</b></td><td><?php echo $data['ali']['status_text']?></td></tr>
		<?php if(isset($data['ali']['reason'])){?><tr><td><b>报备失败原因</b></td><td><font color="red"><?php echo $data['ali']['reason']?></font></td></tr><?php }?>
		<?php if(isset($data['ali']['sub_mch_id'])){?><tr><td><b>支付宝子商户号</b></td><td><?php echo $data['ali']['sub_mch_id']?></td></tr><?php }?>
		<?php if(isset($data['ali']['channel'])){?><tr><td><b>报备渠道号</b></td><td><?php echo $data['ali']['channel']?></td></tr><?php }?>
		<?php if($data['ali']['real_status']){?><tr><td><b>实名认证申请单</b></td><td>
			状态：<?php echo $data['ali']['real_status_text']?> <?php if(!empty($data['ali']['real_reason'])){?>（原因：<font color="red"><?php echo $data['ali']['real_reason']?></font>）<?php }?>
			<?php
			if($data['ali']['real_status']=='LEGAL_CONFIRM'||$data['ali']['real_status']=='CONTACT_CONFIRM'){
				echo '<br/><br/>请使用支付宝扫描以下二维码完成认证：<br/><img height="180px" src="'.$data['ali']['qrcode'].'">';
			}
			?>
		</td></tr><?php }?>
	</tbody>
</table><hr/>
<?php }?>

<?php if(isset($data['wx'])){?> 
<table class="table table-hover table-bordered">
	<tbody>
		<tr><td colspan="2"><strong style="font-size:large">微信支付</strong></td></tr>
		<tr><td><b>微信报备状态</b></td><td><?php echo $data['wx']['status_text']?></td></tr>
		<?php if(isset($data['wx']['reason'])){?><tr><td><b>报备失败原因</b></td><td><font color="red"><?php echo $data['wx']['reason']?></font></td></tr><?php }?>
		<?php if(isset($data['wx']['sub_mch_id'])){?><tr><td><b>微信子商户号</b></td><td><?php echo $data['wx']['sub_mch_id']?></td></tr><?php }?>
		<?php if(isset($data['wx']['channel'])){?><tr><td><b>报备渠道号</b></td><td><?php echo $data['wx']['channel']?></td></tr><?php }?>
		<?php if($data['wx']['real_status']){?><tr><td><b>实名认证申请单</b></td><td>
			状态：<?php echo $data['wx']['real_status_text']?> <?php if(!empty($data['wx']['real_reason'])){?>（原因：<font color="red"><?php echo $data['wx']['real_reason']?></font>）<?php }?>
			<?php
			if($data['wx']['real_status']=='APPLYMENT_STATE_WAITTING_FOR_CONFIRM_CONTACT'||$data['wx']['real_status']=='APPLYMENT_STATE_WAITTING_FOR_CONFIRM_LEGALPERSON'||$data['wx']['real_status']=='APPLYMENT_STATE_FREEZED'){
				echo '<br/><br/>请使用微信扫描以下二维码完成认证：<br/><img height="180px" src="'.$data['wx']['qrcode'].'">';
			}
			?>
		</td></tr><?php }?>
	</tbody>
</table><hr/>
<?php }?>

<?php if(isset($data['zft'])){?> 
<table class="table table-hover table-bordered">
	<tbody>
		<tr><td colspan="2"><strong style="font-size:large">支付宝直付通</strong></td></tr>
		<tr><td><b>风控审核状态</b></td><td><?php echo $data['zft']['fk_status_text']?></td></tr>
		<tr><td><b>客资审核状态</b></td><td><?php echo $data['zft']['kz_status_text']?></td></tr>
		<tr><td><b>二级商户ID</b></td><td><?php echo $data['zft']['sub_mch_id']?></td></tr>
		<tr><td><b>二级商户确认状态</b></td><td><?php echo $data['zft']['confirm_status_text']?></td></tr>
	</tbody>
</table><hr/>
<?php }?>

<?php if(isset($data['bank'])){?> 
<table class="table table-hover table-bordered">
	<tbody>
		<tr><td colspan="2"><strong style="font-size:large">银联支付</strong></td></tr>
		<tr><td><b>银联报备状态</b></td><td><?php echo $data['bank']['status_text']?></td></tr>
		<?php if(isset($data['bank']['reason'])){?><tr><td><b>报备失败原因</b></td><td><font color="red"><?php echo $data['bank']['reason']?></font></td></tr><?php }?>
		<?php if(isset($data['bank']['sub_mch_id'])){?><tr><td><b>银联子商户号</b></td><td><?php echo $data['bank']['sub_mch_id']?></td></tr><?php }?>
	</tbody>
</table><hr/>
<?php }?>

</div>
</div>
<?php register_shutdown_function(function() use($row, $cdnpublic){?>
<script src="<?php echo $cdnpublic?>layer/3.1.1/layer.js"></script>
<script>
function submit(act) {
	var ii = layer.load(2, {shade:[0.1,'#fff']});
	$.ajax({
		type : 'POST',
		url : 'ajax_applyments.php?act=query',
		data : {action:'realNameAction', id:<?php echo $row['id']?>, act: act},
		dataType : 'json',
		success : function(data) {
			layer.close(ii);
			if(data.code == 0){
				layer.alert(data.msg, {icon: 1}, function(){
					layer.closeAll();
					if(data.update){
						location.reload();
					}
				});
			}else{
				layer.alert(data.msg, {icon: 2});
			}
		}
	});
	return false;
}
</script>
<?php });?>