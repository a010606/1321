<?php
/**
 * 通道健康度监控（二开功能）
 * 入口：后台顶部导航 → 支付接口 → 通道健康度
 *      或直接访问 /admin/channel_health.php
**/
include("../includes/common.php");
$title='通道健康度监控';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<link href="../assets/css/dashboard.css" rel="stylesheet"/>
<div class="container-fluid dash-wrap">

  <div class="dash-kpi">
    <div class="dash-kpi-card">
      <div class="dash-kpi-label">运行正常</div>
      <div class="dash-kpi-value" id="sum_good">--</div>
      <div class="dash-kpi-sub">成功率正常且无连续失败</div>
      <i class="fa fa-check-circle dash-kpi-ico"></i>
    </div>
    <div class="dash-kpi-card">
      <div class="dash-kpi-label">需要关注</div>
      <div class="dash-kpi-value" id="sum_warn">--</div>
      <div class="dash-kpi-sub">成功率偏低</div>
      <i class="fa fa-exclamation-circle dash-kpi-ico"></i>
    </div>
    <div class="dash-kpi-card">
      <div class="dash-kpi-label">异常通道</div>
      <div class="dash-kpi-value" id="sum_bad">--</div>
      <div class="dash-kpi-sub">成功率低于30%或连续失败</div>
      <i class="fa fa-times-circle dash-kpi-ico"></i>
    </div>
    <div class="dash-kpi-card">
      <div class="dash-kpi-label">已停用</div>
      <div class="dash-kpi-value" id="sum_off">--</div>
      <div class="dash-kpi-sub">后台手动停用的通道</div>
      <i class="fa fa-power-off dash-kpi-ico"></i>
    </div>
  </div>

  <div class="dash-card">
    <div class="dash-card-hd">
      <span>通道健康明细</span>
      <div class="dash-tab">
        <a href="javascript:;" class="on" data-hours="24">近24小时</a>
        <a href="javascript:;" data-hours="72">近3天</a>
        <a href="javascript:;" data-hours="168">近7天</a>
      </div>
    </div>

    <div class="ch-filter">
      <a href="javascript:;" class="on" data-f="all">全部</a>
      <a href="javascript:;" data-f="good">正常</a>
      <a href="javascript:;" data-f="warn">关注</a>
      <a href="javascript:;" data-f="bad">异常</a>
      <a href="javascript:;" data-f="off">停用</a>
    </div>

    <div class="table-responsive">
      <table class="table table-hover ch-table">
        <thead>
          <tr>
            <th style="width:60px">状态</th>
            <th style="width:70px">ID</th>
            <th>通道名称</th>
            <th style="width:110px">支付方式</th>
            <th style="width:100px">插件</th>
            <th style="width:90px">订单数</th>
            <th style="width:110px">成交金额</th>
            <th style="width:150px">成功率</th>
            <th style="width:200px">诊断</th>
            <th style="width:100px">操作</th>
          </tr>
        </thead>
        <tbody id="ch_body"></tbody>
      </table>
    </div>
  </div>
</div>

<script>
var CUR_HOURS = 24;
var CUR_FILTER = 'all';
var RAW = [];

function healthTag(h){
  var map = {
    good:['正常','ch-t-ok'],
    warn:['关注','ch-t-warn'],
    bad:['异常','ch-t-bad'],
    off:['停用','ch-t-off'],
    idle:['空闲','ch-t-idle']
  };
  var m = map[h] || map.idle;
  return '<span class="ch-tag '+m[1]+'"><i></i>'+m[0]+'</span>';
}

function rateBar(v){
  if(v === null) return '<span class="ch-na">无数据</span>';
  var cls = v >= 60 ? 'ok' : (v >= 30 ? 'warn' : 'bad');
  return '<div class="ch-rate">'
       + '<div class="ch-rate-c"><i class="'+cls+'" style="width:'+Math.max(2,v)+'%"></i></div>'
       + '<b class="'+cls+'">'+v+'%</b></div>';
}

function render(){
  var list = RAW;
  if(CUR_FILTER !== 'all'){
    list = RAW.filter(function(r){ return r.health === CUR_FILTER; });
  }
  var html = '';
  for(var i=0;i<list.length;i++){
    var r = list[i];
    var streakTip = r.streak > 0 ? '　连续 '+r.streak+' 笔未支付' : '';
    html += '<tr>'
          + '<td>'+healthTag(r.health)+'</td>'
          + '<td>'+r.id+'</td>'
          + '<td><b>'+r.name+'</b></td>'
          + '<td>'+(r.typename||'-')+'</td>'
          + '<td><code>'+r.plugin+'</code></td>'
          + '<td>'+r.total+' 笔</td>'
          + '<td>¥'+(r.money||0).toFixed(2)+'</td>'
          + '<td>'+rateBar(r.srate)+'</td>'
          + '<td class="ch-reason">'+r.reason+streakTip+'</td>'
          + '<td><a href="./pay_channel.php?kw='+r.id+'" target="_blank" class="btn btn-default btn-xs">配置</a></td>'
          + '</tr>';
  }
  if(!html) html = '<tr><td colspan="10" style="text-align:center;color:#8fa3b8;padding:30px">没有符合条件的通道</td></tr>';
  document.getElementById('ch_body').innerHTML = html;
}

function loadData(){
  $.getJSON('ajax.php?act=channelHealth&hours='+CUR_HOURS, function(res){
    if(res.code !== 0) return;
    RAW = res.list;
    document.getElementById('sum_good').textContent = res.sum.good;
    document.getElementById('sum_warn').textContent = res.sum.warn;
    document.getElementById('sum_bad').textContent  = res.sum.bad;
    document.getElementById('sum_off').textContent  = res.sum.off;
    render();
  });
}

$(document).ready(function(){
  loadData();
  setInterval(loadData, 60000);
  $('.dash-tab a').click(function(){
    $('.dash-tab a').removeClass('on');
    $(this).addClass('on');
    CUR_HOURS = parseInt($(this).data('hours'));
    loadData();
  });
  $('.ch-filter a').click(function(){
    $('.ch-filter a').removeClass('on');
    $(this).addClass('on');
    CUR_FILTER = $(this).data('f');
    render();
  });
});
</script>
