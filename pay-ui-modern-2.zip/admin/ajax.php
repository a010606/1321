<?php
include("../includes/common.php");
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
$act=isset($_GET['act'])?daddslashes($_GET['act']):null;

if(!checkRefererHost())exit('{"code":403}');

@header('Content-Type: application/json; charset=UTF-8');

switch($act){
case 'dashData': //实时数据大屏
	$today = date('Y-m-d');
	$hours = intval($_GET['hours']);
	if($hours <= 0) $hours = 24;

	// 今日概览
	// 成功率与订单数口径：与源码自带算法（admin/ajax.php getcount）完全一致
	//   1) 时间条件用 addtime>=今日00:00:00
	//   2) status>0 记为成功
	//   3) 无订单时显示 100（源码如此，不是 0）
	//   4) 保留 2 位小数
	$thtime       = date('Y-m-d').' 00:00:00';
	$today_all    = intval($DB->getColumn("SELECT COUNT(*) FROM pre_order WHERE addtime>=:t", [':t'=>$thtime]));
	$today_ok     = intval($DB->getColumn("SELECT COUNT(*) FROM pre_order WHERE addtime>=:t AND status>0", [':t'=>$thtime]));
	$today_money  = floatval($DB->getColumn("SELECT IFNULL(SUM(realmoney),0) FROM pre_order WHERE addtime>=:t AND status>0", [':t'=>$thtime]));
	// 利润口径：用订单表自带的 profitmoney 字段（源码统计利润即以此为准，
	// 该字段已扣除通道成本）。此前误用 realmoney-getmoney，与源码不一致。
	$today_profit = floatval($DB->getColumn("SELECT IFNULL(SUM(profitmoney),0) FROM pre_order WHERE addtime>=:t AND status>0", [':t'=>$thtime]));
	$rate = $today_all > 0 ? round($today_ok / $today_all * 100, 2) : 100;

	// 近N小时趋势（按小时聚合）
	$stime = date('Y-m-d H:i:s', time() - $hours*3600);
	$trend = [];
	$rows = $DB->getAll("SELECT DATE_FORMAT(addtime,'%m-%d %H:00') h, count(*) c, IFNULL(SUM(CASE WHEN status>0 THEN realmoney ELSE 0 END),0) m FROM pre_order WHERE addtime>=:s GROUP BY h ORDER BY h ASC", [':s'=>$stime]);
	$map = [];
	foreach($rows as $r){ $map[$r['h']] = ['c'=>intval($r['c']), 'm'=>floatval($r['m'])]; }
	for($i=$hours-1; $i>=0; $i--){
		$h = date('m-d H:00', time() - $i*3600);
		$trend[] = ['h'=>$h, 'c'=>isset($map[$h])?$map[$h]['c']:0, 'm'=>isset($map[$h])?$map[$h]['m']:0];
	}

	// 支付方式分布（今日）
	$paytype = [];
	$rows = $DB->getAll("SELECT B.showname name, count(*) c, IFNULL(SUM(A.realmoney),0) m FROM pre_order A LEFT JOIN pre_type B ON A.type=B.id WHERE A.addtime>=:t AND A.status>0 GROUP BY A.type,B.showname ORDER BY m DESC", [':t'=>$thtime]);
	foreach($rows as $r){ $paytype[] = ['name'=>$r['name']?$r['name']:'其他', 'c'=>intval($r['c']), 'm'=>floatval($r['m'])]; }

	// 实时订单流（最近15笔）
	$list = $DB->getAll("SELECT A.trade_no,A.uid,A.name,A.money,A.realmoney,A.status,A.addtime,A.ip,B.showname typename FROM pre_order A LEFT JOIN pre_type B ON A.type=B.id ORDER BY A.addtime DESC LIMIT 15");
	foreach($list as &$r){ $r['money'] = floatval($r['money']); $r['realmoney'] = floatval($r['realmoney']); }
	unset($r);

	// 商户与通道总量
	$usercount   = intval($DB->getColumn("SELECT count(*) FROM pre_user"));
	$channel_on  = intval($DB->getColumn("SELECT count(*) FROM pre_channel WHERE status=1"));
	$channel_all = intval($DB->getColumn("SELECT count(*) FROM pre_channel"));
	$unpaid      = intval($DB->getColumn("SELECT COUNT(*) FROM pre_order WHERE addtime>=:t AND status=0", [':t'=>$thtime]));

	exit(json_encode([
		'code'=>0,
		'today_all'=>$today_all, 'today_ok'=>$today_ok, 'unpaid'=>$unpaid,
		'today_money'=>round($today_money,2), 'today_profit'=>round($today_profit,2),
		'rate'=>$rate, 'trend'=>$trend, 'paytype'=>$paytype, 'list'=>$list,
		'usercount'=>$usercount, 'channel_on'=>$channel_on, 'channel_all'=>$channel_all,
		'now'=>date('Y-m-d H:i:s')
	]));
break;

case 'channelHealth': //通道健康度监控
	$hours = intval($_GET['hours']);
	if($hours <= 0) $hours = 24;
	$stime = date('Y-m-d H:i:s', time() - $hours*3600);

	$channels = $DB->getAll("SELECT A.id,A.name,A.plugin,A.status,A.rate,B.showname typename FROM pre_channel A LEFT JOIN pre_type B ON A.type=B.id ORDER BY A.status DESC,A.id ASC");
	$data = [];
	foreach($channels as $ch){
		$cid = intval($ch['id']);
		$total = intval($DB->getColumn("SELECT count(*) FROM pre_order WHERE channel=:c AND addtime>=:s", [':c'=>$cid, ':s'=>$stime]));
		$ok    = intval($DB->getColumn("SELECT count(*) FROM pre_order WHERE channel=:c AND addtime>=:s AND status>0", [':c'=>$cid, ':s'=>$stime]));
		$money = floatval($DB->getColumn("SELECT IFNULL(SUM(realmoney),0) FROM pre_order WHERE channel=:c AND addtime>=:s AND status>0", [':c'=>$cid, ':s'=>$stime]));
		// 连续失败数（最近20笔里末尾连续未支付）
		$last = $DB->getAll("SELECT status FROM pre_order WHERE channel=:c ORDER BY addtime DESC LIMIT 20", [':c'=>$cid]);
		$streak = 0;
		foreach($last as $r){ if(intval($r['status'])==0) $streak++; else break; }
		// 成功率：与源码 getcount 口径一致 —— 无订单时为 100（不是 0/null）
		$srate = $total > 0 ? round($ok/$total*100, 1) : 100;

		// 健康判定
		if($ch['status']==0){ $health='off'; $reason='通道已停用'; }
		elseif($total==0){ $health='idle'; $reason='近期无订单'; }
		elseif($srate < 30){ $health='bad'; $reason='成功率低于30%'; }
		elseif($streak >= 5){ $health='bad'; $reason='连续'.$streak.'笔未支付'; }
		elseif($srate < 60){ $health='warn'; $reason='成功率偏低'; }
		else { $health='good'; $reason='运行正常'; }

		$data[] = [
			'id'=>$cid, 'name'=>$ch['name'], 'plugin'=>$ch['plugin'],
			'typename'=>$ch['typename'], 'status'=>intval($ch['status']),
			'total'=>$total, 'ok'=>$ok, 'money'=>round($money,2),
			'srate'=>$srate, 'streak'=>$streak, 'health'=>$health, 'reason'=>$reason
		];
	}
	// 统计
	$sum = ['good'=>0,'warn'=>0,'bad'=>0,'off'=>0,'idle'=>0];
	foreach($data as $d) $sum[$d['health']]++;
	exit(json_encode(['code'=>0, 'list'=>$data, 'sum'=>$sum, 'hours'=>$hours]));
break;






case 'getcount':
	$thtime=date("Y-m-d").' 00:00:00';
	$count1=$DB->getColumn("SELECT count(*) from pre_order");
	$count2=$DB->getColumn("SELECT count(*) from pre_user");
	$plugincount=$DB->getColumn("SELECT count(*) from pre_plugin");
	if($plugincount<1){
		\lib\Plugin::updateAll();
	}
	$isConvert = $DB->getRow("SELECT * FROM pre_channel WHERE status=1 AND config IS NULL LIMIT 1");
	if($isConvert){
		convert_channel_data();
		\lib\Plugin::updateAll();
	}

	$orderrow=$DB->getRow("SELECT COUNT(*) allnum,COUNT(IF(status>0, 1, NULL)) sucnum FROM pre_order WHERE addtime>='$thtime'");
	$success_rate = 100;
	if($orderrow){
		if($orderrow['allnum'] > 0){
			$success_rate = round($orderrow['sucnum']/$orderrow['allnum']*100,2);
		}
	}

	$paytype = [];
	$rs = $DB->getAll("SELECT id,name,showname FROM pre_type WHERE status=1");
	foreach($rs as $row){
		$paytype[$row['id']] = $row['showname'];
	}
	unset($rs);

	$channel = [];
	$rs = $DB->getAll("SELECT id,name FROM pre_channel WHERE status=1");
	foreach($rs as $row){
		$channel[$row['id']] = $row['name'];
	}
	unset($rs);

	// ==================================================================
	// ★ 修复：三个统计表「今日」行长期显示 0
	// ------------------------------------------------------------------
	// 原逻辑把 order_today 一起塞进 1 小时缓存（pre_cache 的 tongji）。
	// 缓存是「生成那一刻的快照」，缓存期内新完成的订单不会体现，
	// 于是首页「支付方式收入 / 通道收入 / 手续费利润」三张表的
	// 「今日」行会一直显示 0，直到缓存过期或被手动刷新。
	//
	// 改为：今日统计【实时计算】（今日订单量小，一条聚合查询代价可接受），
	//       只有「商户余额 / 结算额 / 历史7天」继续走缓存。
	// ==================================================================
	$today=date("Y-m-d");
	$rs=$DB->query("SELECT type,channel,realmoney,profitmoney from pre_order where status=1 and date>='$today'");
	$order_paytype = [];
	$profit_paytype = [];
	$order_channel = [];
	foreach($paytype as $id=>$type){
		$order_paytype[$id]=0;
		$profit_paytype[$id]=0;
	}
	foreach($channel as $id=>$type){
		$order_channel[$id]=0;
	}
	while($row = $rs->fetch())
	{
		$order_paytype[$row['type']]+=$row['realmoney'];
		$order_channel[$row['channel']]+=$row['realmoney'];
		if(!empty($row['profitmoney'])){
			$profit_paytype[$row['type']]+=$row['profitmoney'];
		}
	}
	foreach($order_paytype as $k=>$v){
		$order_paytype[$k] = round($v,2);
	}
	foreach($order_channel as $k=>$v){
		$order_channel[$k] = round($v,2);
	}
	foreach($profit_paytype as $k=>$v){
		$profit_paytype[$k] = round($v,2);
	}
	$allmoney=0;
	foreach($order_paytype as $order){
		$allmoney+=$order;
	}
	$allprofit=0;
	foreach($profit_paytype as $money){
		$allprofit+=$money;
	}
	$order_today['all']=round($allmoney,2);
	$order_today['profit_all']=round($allprofit,2);
	$order_today['paytype']=$order_paytype;
	$order_today['channel']=$order_channel;
	$order_today['profit_paytype']=$profit_paytype;

	// 余额与结算额：保留 1 小时缓存（这两项数据量大且变化慢）
	$tongji_cachetime=getSetting('tongji_cachetime', true);
	$tongji_cache = $CACHE->read('tongji');
	if($tongji_cachetime+3600>=time() && $tongji_cache && !isset($_GET['getnew'])){
		$array = unserialize($tongji_cache);
		$usermoney = isset($array['usermoney'])?$array['usermoney']:0;
		$settlemoney = isset($array['settlemoney'])?$array['settlemoney']:0;
		$result=["code"=>0,"type"=>"cache","paytype"=>$paytype,"channel"=>$channel,"count1"=>$count1,"count2"=>$count2,"usermoney"=>round($usermoney,2),"settlemoney"=>round($settlemoney,2),"success_rate"=>$success_rate,"order_today"=>$order_today,"order"=>[]];
	}else{
		$usermoney=$DB->getColumn("SELECT SUM(money) FROM pre_user WHERE money!='0.00'");
		$settlemoney=$DB->getColumn("SELECT SUM(money) FROM pre_settle");

		saveSetting('tongji_cachetime',time());
		$CACHE->save('tongji',serialize(["usermoney"=>$usermoney,"settlemoney"=>$settlemoney]));

		$result=["code"=>0,"type"=>"online","paytype"=>$paytype,"channel"=>$channel,"count1"=>$count1,"count2"=>$count2,"usermoney"=>round($usermoney,2),"settlemoney"=>round($settlemoney,2),"success_rate"=>$success_rate,"order_today"=>$order_today,"order"=>[]];
	}
	for($i=1;$i<7;$i++){
		$day = date("Ymd", strtotime("-{$i} day"));
		if($order_tongji = $CACHE->read('order_'.$day)){
			$result["order"][$day] = unserialize($order_tongji);
		}else{
			break;
		}
	}
	exit(json_encode($result));
break;

case 'set':
	if(isset($_POST['localurl'])){
		if(!empty($_POST['localurl']) && (substr($_POST['localurl'],0,4)!='http' || substr($_POST['localurl'],-1)!='/'))exit('{"code":-1,"msg":"回调专用网址格式错误"}');
	}
	if(isset($_POST['apiurl'])){
		if(!empty($_POST['apiurl']) && (substr($_POST['apiurl'],0,4)!='http' || substr($_POST['apiurl'],-1)!='/'))exit('{"code":-1,"msg":"用户对接网址格式错误"}');
	}
	if(isset($_POST['login_apiurl'])){
		if(!empty($_POST['login_apiurl']) && (substr($_POST['login_apiurl'],0,4)!='http' || substr($_POST['login_apiurl'],-1)!='/'))exit('{"code":-1,"msg":"聚合登录API接口地址格式错误"}');
	}
	foreach($_POST as $k=>$v){
		saveSetting($k, $v);
	}
	$ad=$CACHE->clear();
	if($ad)exit('{"code":0,"msg":"succ"}');
	else exit('{"code":-1,"msg":"修改设置失败['.$DB->error().']"}');
break;
case 'setGonggao':
	$id=intval($_GET['id']);
	$status=intval($_GET['status']);
	$sql = "UPDATE pre_anounce SET status='$status' WHERE id='$id'";
	if($DB->exec($sql))exit('{"code":0,"msg":"修改状态成功！"}');
	else exit('{"code":-1,"msg":"修改状态失败['.$DB->error().']"}');
break;
case 'delGonggao':
	$id=intval($_GET['id']);
	$sql = "DELETE FROM pre_anounce WHERE id='$id'";
	if($DB->exec($sql))exit('{"code":0,"msg":"删除公告成功！"}');
	else exit('{"code":-1,"msg":"删除公告失败['.$DB->error().']"}');
break;
case 'iptype':
	$result = [
	['name'=>'0_X_FORWARDED_FOR', 'ip'=>real_ip(0), 'city'=>get_ip_city(real_ip(0))],
	['name'=>'1_X_REAL_IP', 'ip'=>real_ip(1), 'city'=>get_ip_city(real_ip(1))],
	['name'=>'2_REMOTE_ADDR', 'ip'=>real_ip(2), 'city'=>get_ip_city(real_ip(2))]
	];
	exit(json_encode($result));
break;

case 'setArticle': //文章状态
	$id=intval($_GET['id']);
	$active=intval($_GET['active']);
	$DB->exec("update pre_article set active='$active' where id='{$id}'");
	exit('{"code":0,"msg":"succ"}');
break;
case 'article_upload':
	$file_name = $_FILES['imgFile']['name'];
	$tmp_name = $_FILES['imgFile']['tmp_name'];
	//获得文件扩展名
	$temp_arr = explode(".", $file_name);
	$file_ext = array_pop($temp_arr);
	$file_ext = strtolower(trim($file_ext));
	if (in_array($file_ext, array('gif', 'jpg', 'jpeg', 'png', 'bmp', 'webp')) === false) {
		exit('{"error":1,"message":"上传文件扩展名是不允许的扩展名。"}');
	}
	$filename = md5_file($tmp_name).'.'.$file_ext;
	$fileurl = '/assets/img/article/'.$filename;
	if(copy($tmp_name, ROOT.'assets/img/article/'.$filename)){
		exit('{"error":0,"url":"'.$fileurl.'"}');
	}else{
		exit('{"error":1,"message":"上传失败，请确保有本地写入权限"}');
	}
break;

case 'testproxy':
	$conf['proxy_server'] = trim($_POST['proxy_server']);
	$conf['proxy_port'] = $_POST['proxy_port'];
	$conf['proxy_user'] = trim($_POST['proxy_user']);
	$conf['proxy_pwd'] = trim($_POST['proxy_pwd']);
	$conf['proxy_type'] = $_POST['proxy_type'];
	try{
		check_proxy('https://dl.amh.sh/ip.htm');
	}catch(Exception $e){
		try{
			check_proxy('https://myip.ipip.net/');
		}catch(Exception $e){
			exit('{"code":-1,"msg":"'.$e->getMessage().'"}');
		}
	}
	exit('{"code":0}');
break;

default:
	exit('{"code":-4,"msg":"No Act"}');
break;
}