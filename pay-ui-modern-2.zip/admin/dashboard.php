<?php
/**
 * 实时数据大屏（二开功能）
 * 入口：后台顶部导航 → 平台首页 → 数据大屏
 *      或直接访问 /admin/dashboard.php
**/
include("../includes/common.php");
$title='实时数据大屏';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<link href="../assets/css/dashboard.css" rel="stylesheet"/>
<div class="container-fluid dash-wrap">

  <!-- 顶部指标 -->
  <div class="dash-kpi">
    <div class="dash-kpi-card">
      <div class="dash-kpi-label">今日交易额</div>
      <div class="dash-kpi-value" id="kpi_money">--</div>
      <div class="dash-kpi-sub">已支付订单实付金额</div>
      <i class="fa fa-cny dash-kpi-ico"></i>
    </div>
    <div class="dash-kpi-card">
      <div class="dash-kpi-label">今日订单数</div>
      <div class="dash-kpi-value" id="kpi_count">--</div>
      <div class="dash-kpi-sub"><span id="kpi_ok">0</span> 笔成功 / <span id="kpi_unpaid">0</span> 笔未付</div>
      <i class="fa fa-file-text-o dash-kpi-ico"></i>
    </div>
    <div class="dash-kpi-card">
      <div class="dash-kpi-label">支付成功率</div>
      <div class="dash-kpi-value" id="kpi_rate">--</div>
      <div class="dash-kpi-sub">成功订单 / 总订单</div>
      <i class="fa fa-line-chart dash-kpi-ico"></i>
    </div>
    <div class="dash-kpi-card">
      <div class="dash-kpi-label">今日利润</div>
      <div class="dash-kpi-value" id="kpi_profit">--</div>
      <div class="dash-kpi-sub">实付金额 - 商户分成</div>
      <i class="fa fa-pie-chart dash-kpi-ico"></i>
    </div>
  </div>

  <div class="dash-row">
    <!-- 成功率环形图 -->
    <div class="dash-card dash-card-sm">
      <div class="dash-card-hd"><span>支付成功率</span><em id="rate_time">--</em></div>
      <div class="dash-ring-box">
        <svg viewBox="0 0 120 120" class="dash-ring">
          <circle cx="60" cy="60" r="52" class="dash-ring-bg"/>
          <circle cx="60" cy="60" r="52" class="dash-ring-fg" id="ring_fg"/>
        </svg>
        <div class="dash-ring-txt">
          <b id="ring_val">0%</b>
          <span>成功率</span>
        </div>
      </div>
      <div class="dash-legend">
        <span><i class="dash-dot dash-dot-ok"></i>成功 <b id="lg_ok">0</b></span>
        <span><i class="dash-dot dash-dot-no"></i>未付 <b id="lg_no">0</b></span>
      </div>
    </div>

    <!-- 24小时趋势 -->
    <div class="dash-card dash-card-lg">
      <div class="dash-card-hd">
        <span>近24小时交易趋势</span>
        <div class="dash-tab">
          <a href="javascript:;" class="on" data-hours="24">24小时</a>
          <a href="javascript:;" data-hours="72">3天</a>
          <a href="javascript:;" data-hours="168">7天</a>
        </div>
      </div>
      <div class="dash-chart" id="trend_chart"></div>
    </div>

    <!-- 支付方式分布 -->
    <div class="dash-card dash-card-sm">
      <div class="dash-card-hd"><span>今日支付方式分布</span></div>
      <div class="dash-bars" id="paytype_bars"></div>
    </div>
  </div>

  <div class="dash-row">
    <!-- 实时订单流 -->
    <div class="dash-card dash-card-lg">
      <div class="dash-card-hd">
        <span>实时订单流</span>
        <a href="javascript:loadData()" class="dash-refresh"><i class="fa fa-refresh"></i> 刷新</a>
      </div>
      <div class="dash-flow" id="order_flow"></div>
    </div>

    <!-- 系统概览 -->
    <div class="dash-card dash-card-sm">
      <div class="dash-card-hd"><span>系统概览</span></div>
      <div class="dash-sys">
        <div class="dash-sys-item"><span>商户总数</span><b id="sys_user">--</b></div>
        <div class="dash-sys-item"><span>通道（启用/总）</span><b id="sys_ch">--</b></div>
        <div class="dash-sys-item"><span>今日未支付</span><b id="sys_unpaid">--</b></div>
        <div class="dash-sys-item"><span>数据更新时间</span><b id="sys_time">--</b></div>
      </div>
      <div class="dash-quick">
        <a href="./order.php" class="dash-qbtn"><i class="fa fa-list"></i>订单管理</a>
        <a href="./channel_health.php" class="dash-qbtn"><i class="fa fa-heartbeat"></i>通道健康</a>
      </div>
    </div>
  </div>
</div>

<script>
var CUR_HOURS = 24;
var timer = null;

function fmtMoney(n){
  n = parseFloat(n)||0;
  if(n >= 10000) return (n/10000).toFixed(2)+'万';
  return n.toFixed(2);
}

function renderRing(rate){
  var r = 52, c = 2*Math.PI*r;
  var pct = Math.max(0, Math.min(100, parseFloat(rate)||0));
  var fg = document.getElementById('ring_fg');
  fg.style.strokeDasharray = c;
  fg.style.strokeDashoffset = c * (1 - pct/100);
  document.getElementById('ring_val').textContent = pct.toFixed(1)+'%';
}

function renderTrend(trend){
  var box = document.getElementById('trend_chart');
  if(!trend.length){ box.innerHTML = '<div class="dash-empty">暂无数据</div>'; return; }
  var max = 0;
  for(var i=0;i<trend.length;i++){ if(trend[i].m > max) max = trend[i].m; }
  if(max <= 0) max = 1;
  var html = '<div class="dash-bars-v">';
  var step = Math.ceil(trend.length / 24);
  for(var i=0;i<trend.length;i++){
    if(i % step !== 0 && i !== trend.length-1) continue;
    var h = Math.max(2, Math.round(trend[i].m / max * 100));
    html += '<div class="dash-bar-col" title="'+trend[i].h+'  '+fmtMoney(trend[i].m)+'元 / '+trend[i].c+'笔">'
          + '<span class="dash-bar-tip">'+fmtMoney(trend[i].m)+'</span>'
          + '<i style="height:'+h+'%"></i>'
          + '<em>'+trend[i].h.split(' ')[1]+'</em></div>';
  }
  html += '</div>';
  box.innerHTML = html;
}

function renderPaytype(list){
  var box = document.getElementById('paytype_bars');
  if(!list.length){ box.innerHTML = '<div class="dash-empty">今日暂无成功订单</div>'; return; }
  var max = list[0].m || 1;
  var html = '';
  for(var i=0;i<list.length;i++){
    var w = Math.max(3, Math.round(list[i].m / max * 100));
    html += '<div class="dash-hbar">'
          + '<div class="dash-hbar-t"><span>'+list[i].name+'</span><b>¥'+fmtMoney(list[i].m)+'</b></div>'
          + '<div class="dash-hbar-c"><i style="width:'+w+'%"></i></div>'
          + '<div class="dash-hbar-s">'+list[i].c+' 笔</div>'
          + '</div>';
  }
  box.innerHTML = html;
}

function renderFlow(list){
  var box = document.getElementById('order_flow');
  if(!list.length){ box.innerHTML = '<div class="dash-empty">暂无订单</div>'; return; }
  var html = '';
  for(var i=0;i<list.length;i++){
    var r = list[i];
    var st = '', cls='';
    if(r.status=='1'){ st='已支付'; cls='ok'; }
    else if(r.status=='2'){ st='已退款'; cls='rf'; }
    else if(r.status=='3'){ st='已冻结'; cls='fz'; }
    else { st='未支付'; cls='no'; }
    html += '<div class="dash-flow-item">'
          + '<span class="dash-flow-dot '+cls+'"></span>'
          + '<span class="dash-flow-no">'+r.trade_no+'</span>'
          + '<span class="dash-flow-name">'+r.name+'</span>'
          + '<span class="dash-flow-type">'+(r.typename||'-')+'</span>'
          + '<span class="dash-flow-money">¥'+(r.realmoney||r.money)+'</span>'
          + '<span class="dash-flow-st '+cls+'">'+st+'</span>'
          + '<span class="dash-flow-time">'+r.addtime+'</span>'
          + '</div>';
  }
  box.innerHTML = html;
}

function loadData(){
  $.getJSON('ajax.php?act=dashData&hours='+CUR_HOURS, function(res){
    if(res.code !== 0) return;
    document.getElementById('kpi_money').innerHTML  = '¥'+fmtMoney(res.today_money);
    document.getElementById('kpi_count').textContent = res.today_all;
    document.getElementById('kpi_ok').textContent    = res.today_ok;
    document.getElementById('kpi_unpaid').textContent= res.unpaid;
    document.getElementById('kpi_rate').textContent  = res.rate+'%';
    document.getElementById('kpi_profit').innerHTML  = '¥'+fmtMoney(res.today_profit);
    document.getElementById('lg_ok').textContent     = res.today_ok;
    document.getElementById('lg_no').textContent     = res.unpaid;
    document.getElementById('sys_user').textContent  = res.usercount;
    document.getElementById('sys_ch').textContent    = res.channel_on+' / '+res.channel_all;
    document.getElementById('sys_unpaid').textContent= res.unpaid;
    document.getElementById('sys_time').textContent  = res.now;
    document.getElementById('rate_time').textContent = res.now;
    renderRing(res.rate);
    renderTrend(res.trend);
    renderPaytype(res.paytype);
    renderFlow(res.list);
  });
}

$(document).ready(function(){
  loadData();
  // 自动刷新：每30秒
  timer = setInterval(loadData, 30000);
  $('.dash-tab a').click(function(){
    $('.dash-tab a').removeClass('on');
    $(this).addClass('on');
    CUR_HOURS = parseInt($(this).data('hours'));
    loadData();
  });
});
</script>
