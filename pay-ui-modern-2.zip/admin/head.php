<?php
@header('Content-Type: text/html; charset=UTF-8');

$admin_cdnpublic = 2;
if($admin_cdnpublic==1){
	$cdnpublic = '//lib.baomitu.com/';
}elseif($admin_cdnpublic==2){
	$cdnpublic = 'https://s4.zstatic.net/ajax/libs/';
}elseif($admin_cdnpublic==4){
	$cdnpublic = '//cdnjs.webstatic.cn/ajax/libs/';
}else{
	$cdnpublic = '//mirrors.sustech.edu.cn/cdnjs/ajax/libs/';
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
  <meta charset="utf-8"/>
  <meta name="renderer" content="webkit">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title><?php echo $title ?></title>
  <link href="<?php echo $cdnpublic?>twitter-bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="../assets/css/bootstrap-table.css?v=1" rel="stylesheet"/>
  <link href="<?php echo $cdnpublic?>font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
  <script src="<?php echo $cdnpublic?>modernizr/2.8.3/modernizr.min.js"></script>
  <script src="<?php echo $cdnpublic?>jquery/2.1.4/jquery.min.js"></script>
  <script src="<?php echo $cdnpublic?>twitter-bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <!--[if lt IE 9]>
    <script src="<?php echo $cdnpublic?>html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="<?php echo $cdnpublic?>respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
<link href="../assets/css/theme-admin.css" rel="stylesheet"/>
<script src="../assets/js/fix-dropdown.js"></script>
</head>
<body class="adm-body">
<?php if($islogin==1){?>

  <!-- ===== 顶部主导航 ===== -->
  <header class="adm-topbar">
    <div class="adm-topbar-inner">

      <!-- 品牌区 -->
      <a class="adm-brand" href="./">
        <span class="adm-brand-mark"><i class="fa fa-cube"></i></span>
        <span class="adm-brand-text">
          <b>支付管理中心</b>
          <em>Payment Console</em>
        </span>
      </a>

      <!-- 主菜单 -->
      <nav class="adm-nav" id="admNav">
        <ul class="adm-nav-list">
          <li class="adm-nav-item <?php echo checkIfActive('index,dashboard')?>">
            <a href="./"><i class="fa fa-home"></i><span>平台首页</span></a>
          </li>
          <li class="adm-nav-item <?php echo checkIfActive('dashboard')?>">
            <a href="./dashboard.php"><i class="fa fa-desktop"></i><span>数据大屏</span></a>
          </li>
          <li class="adm-nav-item adm-has-sub <?php echo checkIfActive('order,export,ps_receiver,ps_order,buyerstat,blacklist')?>">
            <a href="javascript:;" class="adm-sub-toggle"><i class="fa fa-list"></i><span>收款订单</span><i class="fa fa-angle-down adm-caret"></i></a>
            <div class="adm-dropdown">
              <a href="./order.php"><i class="fa fa-file-text-o"></i>订单管理</a>
              <a href="./export.php"><i class="fa fa-download"></i>导出订单</a>
              <a href="./buyerstat.php"><i class="fa fa-users"></i>支付用户统计</a>
              <a href="./blacklist.php"><i class="fa fa-ban"></i>黑名单管理</a>
              <div class="adm-drop-sep"></div>
              <a href="./ps_receiver.php"><i class="fa fa-sitemap"></i>分账规则</a>
              <a href="./ps_order.php"><i class="fa fa-exchange"></i>分账记录</a>
            </div>
          </li>
          <li class="adm-nav-item adm-has-sub <?php echo checkIfActive('settle,settle_batch,slist,transfer,transfer_add,transfer_export,transfer_red,transfer_batch')?>">
            <a href="javascript:;" class="adm-sub-toggle"><i class="fa fa-cloud"></i><span>付款管理</span><i class="fa fa-angle-down adm-caret"></i></a>
            <div class="adm-dropdown">
              <a href="./slist.php"><i class="fa fa-credit-card"></i>结算管理</a>
              <a href="./settle.php"><i class="fa fa-check-square-o"></i>批量结算</a>
              <div class="adm-drop-sep"></div>
              <a href="./transfer.php"><i class="fa fa-history"></i>付款记录</a>
              <a href="./transfer_add.php"><i class="fa fa-plus-circle"></i>新增付款</a>
              <a href="./transfer_red.php"><i class="fa fa-gift"></i>创建红包</a>
              <a href="./transfer_export.php"><i class="fa fa-download"></i>导出付款记录</a>
              <?php if(class_exists('\\lib\\AlipaySATF\\AlipaySATF')){?><a href="./satf_transfer.php"><i class="fa fa-shield"></i>安全发转账记录</a><?php }?>
            </div>
          </li>
          <li class="adm-nav-item adm-has-sub <?php echo checkIfActive('ulist,glist,gedit,group,record,uset,domain,ustat,invitecode,uexport')?>">
            <a href="javascript:;" class="adm-sub-toggle"><i class="fa fa-user"></i><span>商户管理</span><i class="fa fa-angle-down adm-caret"></i></a>
            <div class="adm-dropdown">
              <a href="./ulist.php"><i class="fa fa-list-ul"></i>用户列表</a>
              <a href="./glist.php"><i class="fa fa-cogs"></i>用户组设置</a>
              <a href="./group.php"><i class="fa fa-shopping-cart"></i>用户组购买</a>
              <a href="./record.php"><i class="fa fa-money"></i>资金明细</a>
              <a href="./ustat.php"><i class="fa fa-bar-chart"></i>支付统计</a>
              <?php if($conf['pay_domain_forbid']==1 || $conf['pay_domain_open']==1){?><a href="./domain.php"><i class="fa fa-globe"></i>授权域名</a><?php }?>
              <?php if($conf['reg_open']==2){?><a href="./invitecode.php"><i class="fa fa-ticket"></i>邀请码管理</a><?php }?>
            </div>
          </li>
          <li class="adm-nav-item adm-has-sub <?php echo checkIfActive('pay_channel,pay_roll,pay_type,pay_plugin,pay_weixin,applyments_channel,applyments_merchant,applyments_form,channel_health')?>">
            <a href="javascript:;" class="adm-sub-toggle"><i class="fa fa-credit-card"></i><span>支付接口</span><i class="fa fa-angle-down adm-caret"></i></a>
            <div class="adm-dropdown">
              <a href="./pay_channel.php"><i class="fa fa-random"></i>支付通道</a>
              <a href="./pay_type.php"><i class="fa fa-th-large"></i>支付方式</a>
              <a href="./pay_plugin.php"><i class="fa fa-plug"></i>支付插件</a>
              <a href="./pay_roll.php"><i class="fa fa-refresh"></i>支付通道轮询</a>
              <a href="./pay_weixin.php"><i class="fa fa-weixin"></i>公众号小程序</a>
              <div class="adm-drop-sep"></div>
              <a href="./channel_health.php"><i class="fa fa-heartbeat"></i>通道健康度</a>
              <?php if(class_exists('\\lib\\Applyments\\CommUtil')){?><a href="./applyments_channel.php"><i class="fa fa-bank"></i>进件渠道管理</a>
              <a href="./applyments_merchant.php"><i class="fa fa-id-card-o"></i>进件商户管理</a><?php }?>
            </div>
          </li>
          <li class="adm-nav-item adm-has-sub <?php echo checkIfActive('set,gonggao,set_wxkf')?>">
            <a href="javascript:;" class="adm-sub-toggle"><i class="fa fa-cog"></i><span>系统设置</span><i class="fa fa-angle-down adm-caret"></i></a>
            <div class="adm-dropdown adm-drop-wide">
              <a href="./set.php?mod=site"><i class="fa fa-info-circle"></i>网站信息配置</a>
              <a href="./set.php?mod=pay"><i class="fa fa-credit-card"></i>支付相关配置</a>
              <a href="./set.php?mod=risk"><i class="fa fa-shield"></i>风控检测配置</a>
              <a href="./set.php?mod=settle"><i class="fa fa-calculator"></i>结算规则配置</a>
              <a href="./set.php?mod=transfer"><i class="fa fa-paper-plane-o"></i>转账付款配置</a>
              <a href="./set.php?mod=oauth"><i class="fa fa-key"></i>快捷登录配置</a>
              <a href="./set.php?mod=notice"><i class="fa fa-bell-o"></i>消息提醒配置</a>
              <a href="./set.php?mod=certificate"><i class="fa fa-id-card"></i>实名认证配置</a>
              <a href="./gonggao.php"><i class="fa fa-bullhorn"></i>网站公告配置</a>
              <a href="./set.php?mod=template"><i class="fa fa-desktop"></i>首页模板配置</a>
              <a href="./set.php?mod=mail"><i class="fa fa-envelope-o"></i>邮箱与短信配置</a>
              <a href="./set.php?mod=upimg"><i class="fa fa-picture-o"></i>网站Logo上传</a>
              <a href="./set.php?mod=cron"><i class="fa fa-clock-o"></i>计划任务配置</a>
              <a href="./set_wxkf.php"><i class="fa fa-comments-o"></i>H5跳转微信客服支付</a>
            </div>
          </li>
          <li class="adm-nav-item adm-has-sub <?php echo checkIfActive('clean,log,risk,gettoken,complain,complain_info')?>">
            <a href="javascript:;" class="adm-sub-toggle"><i class="fa fa-cube"></i><span>其他功能</span><i class="fa fa-angle-down adm-caret"></i></a>
            <div class="adm-dropdown">
              <a href="./risk.php"><i class="fa fa-exclamation-triangle"></i>风控记录</a>
              <a href="./log.php"><i class="fa fa-file-text"></i>登录日志</a>
              <a href="./clean.php"><i class="fa fa-trash-o"></i>数据清理</a>
              <a href="./gettoken.php"><i class="fa fa-qrcode"></i>获取用户标识</a>
              <?php if(class_exists('\\lib\\Complain\\CommUtil')){?><a href="./complain.php"><i class="fa fa-frown-o"></i>支付交易投诉</a><?php }?>
              <?php if(class_exists('\\lib\\WxMchRisk')){?><a href="./mchrisk.php"><i class="fa fa-warning"></i>渠道商户违规记录</a><?php }?>
            </div>
          </li>
        </ul>
      </nav>

      <!-- 右侧操作区 -->
      <div class="adm-topbar-right">
        <a href="../" target="_blank" class="adm-icon-btn" title="前台首页"><i class="fa fa-external-link"></i></a>
        <a href="./login.php?logout" class="adm-logout" onclick="return confirm('是否确定退出登录？')">
          <i class="fa fa-power-off"></i><span class="adm-logout-text">退出</span>
        </a>
      </div>

      <button type="button" class="adm-burger" id="admBurger"><i class="fa fa-bars"></i></button>
    </div>
  </header>

  <!-- 移动端遮罩 -->
  <div class="adm-mask" id="admMask"></div>

  <!-- ===== 内容区 ===== -->
<?php }?>

<script>
/* 后台移动端导航：抽屉展开 / 子菜单点击展开 */
(function(){
  var body = document.body;
  var nav  = document.getElementById('admNav');
  var burger = document.getElementById('admBurger');
  var mask = document.getElementById('admMask');
  if(!nav || !burger) return;

  function isMobile(){ return window.innerWidth <= 991; }

  function openNav(){
    if(!isMobile()) return;
    body.classList.add('adm-nav-open');
    if(mask) mask.classList.add('show');
  }
  function closeNav(){
    body.classList.remove('adm-nav-open');
    if(mask) mask.classList.remove('show');
    // 收起所有已展开的子菜单
    var opened = nav.querySelectorAll('.adm-has-sub.adm-open');
    for(var i=0;i<opened.length;i++) opened[i].classList.remove('adm-open');
  }

  burger.addEventListener('click', function(e){
    e.stopPropagation();
    if(body.classList.contains('adm-nav-open')) closeNav(); else openNav();
  });
  if(mask) mask.addEventListener('click', closeNav);

  // 子菜单：移动端点击展开，桌面端保持 hover
  var toggles = nav.querySelectorAll('.adm-sub-toggle');
  for(var i=0;i<toggles.length;i++){
    toggles[i].addEventListener('click', function(e){
      if(!isMobile()) return;      // 桌面端交给 CSS hover
      e.preventDefault();
      var li = this.parentNode;
      var wasOpen = li.classList.contains('adm-open');
      var all = nav.querySelectorAll('.adm-has-sub.adm-open');
      for(var j=0;j<all.length;j++) all[j].classList.remove('adm-open');
      if(!wasOpen) li.classList.add('adm-open');
    });
  }

  // 点击具体链接（非子菜单开关）后自动收起抽屉
  var links = nav.querySelectorAll('.adm-dropdown a, .adm-nav-item > a[href="./"]');
  for(var k=0;k<links.length;k++){
    links[k].addEventListener('click', function(){ closeNav(); });
  }

  // 视口变大时复位
  window.addEventListener('resize', function(){
    if(!isMobile()) closeNav();
  });
  // ESC 关闭
  document.addEventListener('keydown', function(e){
    if(e.keyCode === 27) closeNav();
  });
})();
</script>