<?php
include("../includes/common.php");
$title='添加已进件商户';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
  <div class="container" style="padding-top:70px;">
    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<?php

if(isset($_POST['submit'])){
	if(!checkRefererHost())exit();
	$cid = intval($_POST['cid']);
	$orderid = trim($_POST['orderid']);
	$mchid = trim($_POST['mchid']);
	$mchtype = intval($_POST['mchtype']);
	$mchname = trim($_POST['mchname']);
	$uid = intval($_POST['uid']);
	if(empty($cid) || empty($orderid) || empty($mchid) || empty($mchtype) || empty($mchname))showmsg('必填项不能为空',3);

	$DB->insert('applymerchant', [
		'cid' => $cid,
		'uid' => $uid ? $uid : 0,
		'orderid' => $orderid,
		'thirdid' => '',
		'mchtype' => $mchtype,
		'mchname' => $mchname,
		'mchid' => $mchid,
		'addtime' => 'NOW()',
		'updatetime' => 'NOW()',
		'status' => 4,
		'paid' => 1,
		'info' => json_encode((object)[]),
	]);

	showmsg('添加进件商户成功！',1,'applyments_merchant.php');
}

$channel_select = '';
$channels = $DB->getAll("SELECT * FROM pre_applychannel order by sort asc");
foreach($channels as $row){
	$channel_select .= '<option value="'.$row['id'].'">'.$row['name'].'</option>';
}
$orderid = date('YmdHis').rand(10,99);
?>

	  <div class="panel panel-primary">
        <div class="panel-heading"><h3 class="panel-title">添加已进件商户</h3></div>
        <div class="panel-body">
          <form action="?" method="POST" role="form" class="form-horizontal">
			<div class="form-group">
	          <label class="col-sm-3 control-label">选择进件渠道</label>
	          <div class="col-sm-9"><select name="cid" class="form-control"><?php echo $channel_select?></select></div>
	        </div>
			<div class="form-group">
	          <label class="col-sm-3 control-label">申请单号</label>
	          <div class="col-sm-9"><input type="text" name="orderid" value="<?php echo $orderid?>" class="form-control" placeholder="随机生成"></div>
	        </div>
			<div class="form-group">
	          <label class="col-sm-3 control-label">子商户号</label>
	          <div class="col-sm-9"><input type="text" name="mchid" value="" class="form-control" placeholder="填写在该进件渠道进件成功后的子商户号"></div>
	        </div>
			<div class="form-group">
	          <label class="col-sm-3 control-label">商户类型</label>
	          <div class="col-sm-9"><select name="mchtype" class="form-control"><option value="1">个人</option><option value="2">个体工商户</option><option value="3">企业</option></select></div>
	        </div>
			<div class="form-group">
	          <label class="col-sm-3 control-label">商户名称</label>
	          <div class="col-sm-9"><input type="text" name="mchname" value="" class="form-control" placeholder="可填写个人或企业名称"></div>
	        </div>
			<div class="form-group">
	          <label class="col-sm-3 control-label">绑定本站UID</label>
	          <div class="col-sm-9"><input type="text" name="uid" value="" class="form-control" placeholder="可留空"></div>
	        </div>
            <div class="form-group">
	           <div class="col-sm-offset-3 col-sm-9"><input type="submit" name="submit" value="提交" class="btn btn-primary form-control"><br></div>
	        </div>
          </form>
        </div>
		<div class="panel-footer">
          <span class="glyphicon glyphicon-info-sign"></span> 此处可以手动添加已经进件的商户信息，无需再走进件流程
        </div>
      </div>
    </div>
  </div>
<script src="<?php echo $cdnpublic?>layer/3.1.1/layer.js"></script>
<script>

</script>