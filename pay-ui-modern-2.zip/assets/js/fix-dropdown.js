/* ==========================================================================
   全局修复：表格内下拉菜单被容器裁切，导致"点击不灵敏"
   --------------------------------------------------------------------------
   原因：bootstrap-table 的 .fixed-table-body 有 overflow:auto，
        表格里"操作订单"这类下拉菜单弹出后会被容器边界裁掉，
        看起来就像点了没反应 / 不灵敏。

   方案：下拉展开瞬间把菜单改成 position:fixed 并挂到 body，
        脱离容器层叠上下文；关闭时还原并放回原位。
   适用范围：后台 + 用户中心所有 bootstrap-table 页面
   ========================================================================== */
(function($){
  if(!$) return;

  var $host = null;      // 菜单原来的父节点
  var $curMenu = null;
  var curToggle = null;

  function place($menu, $toggle){
    var r = $toggle[0].getBoundingClientRect();
    var mw = $menu.outerWidth();
    var mh = $menu.outerHeight();

    // 水平：默认左对齐，超出右边界则右对齐
    var left = r.left;
    if(left + mw > window.innerWidth - 8){
      left = window.innerWidth - mw - 8;
    }
    if(left < 8) left = 8;

    // 垂直：下方放不下就翻到上方
    var top = r.bottom + 2;
    if(top + mh > window.innerHeight - 8){
      var up = r.top - mh - 2;
      top = up > 8 ? up : 8;
    }

    // 层级自适应：普通页面 2000 足够；
    // 若菜单原本在 layer 弹窗内（layui 默认 z-index 约 19891014），
    // 必须抬到弹窗之上，否则会被弹窗盖住。
    var z = 2000;
    var anc = $menu[0];
    while(anc && anc !== document.body){
      var cls = anc.className || '';
      if(typeof cls === 'string' && (cls.indexOf('layui-layer') > -1 || cls.indexOf('modal') > -1)){
        z = 19891020;
        break;
      }
      anc = anc.parentNode;
    }

    $menu.css({
      position:'fixed',
      display:'block',        /* 显式声明：元素移动后 inline display 可能丢失 */
      top: top + 'px',
      left: left + 'px',
      zIndex: z,
      maxHeight: (window.innerHeight - 16) + 'px',
      overflowY: 'auto'
    });
  }

  function restore(){
    if(!$curMenu) return;
    $curMenu.css({position:'', display:'', top:'', left:'', zIndex:'', maxHeight:'', overflowY:''});
    if($host && $host.length){
      // 放回原处（保持 DOM 结构与 bootstrap 预期一致）
      // 注意：curToggle 是原生 DOM 元素，必须包成 jQuery 对象才能调 .next()
      if(curToggle && $(curToggle).next('.dropdown-menu').length === 0){
        $(curToggle).after($curMenu);
      }else{
        $host.append($curMenu);
      }
    }
    $curMenu = null; $host = null; curToggle = null;
  }

  $(document).on('shown.bs.dropdown', function(e){
    var $toggle = $(e.relatedTarget);
    if(!$toggle.length) return;

    var $menu = $toggle.next('.dropdown-menu');
    if(!$menu.length) $menu = $toggle.parent().find('.dropdown-menu').first();
    if(!$menu.length) return;

    // 已经浮动的不用重复处理
    if($menu.css('position') === 'fixed') return;

    $host = $menu.parent();
    $curMenu = $menu;
    curToggle = $toggle[0];

    // 挂到 body，彻底脱离表格容器的 overflow 裁切
    $menu.appendTo(document.body);
    place($menu, $toggle);
  });

  $(document).on('hidden.bs.dropdown', function(){
    restore();
  });

  // 滚动 / 缩放时重新定位（菜单仍开着的情况）
  $(window).on('resize scroll', function(){
    if($curMenu && curToggle){
      place($curMenu, $(curToggle));
    }
  });

  // 点击菜单外部时兜底还原
  $(document).on('click', function(e){
    if($curMenu && !$curMenu[0].contains(e.target) && e.target !== curToggle){
      restore();
    }
  });
})(window.jQuery);
