支付系统 UI 二开 v3 · 逐帧渲染验证与 BUG 根治
================================================================

一、这次不是靠推断，是把页面真渲染出来量的
----------------------------------------------------------------
验证环境：Chromium（headless, 1440×900）+ 真实 CSS 组合
  bootstrap3 + user/assets/css/app.css + font.css + bootstrap-table.css
  + datepicker.css（还原其真实的加载顺序）
构造页面：user/order.php（就是你截图那张"订单记录"页）
对比方式：同一份 DOM，只差一个 theme-user.css，
          逐元素 dump getBoundingClientRect + computedStyle，做差。

二、逐帧量出来的 BUG（v2 实测数据）
----------------------------------------------------------------
                            原版      v2主题     差异
  .app-header               226       245       +19   ← 顶栏被撑高
  .app-aside                979       1095      +116  ← 侧栏暴涨
  .app-aside .navi          855       980       +125
  .app-aside 内 li 总高     1055      1175      +120
  页面总高                  1060      1153      +93

逐元素下钻，定位到 6 个 li 单独从 40px 变 60px：
  #3 API信息   #4 修改资料  #5 修改密码
  #6 实名认证  #22 分账规则 #23 分账记录
  → 它们的 <a> 宽度被我从 140px 压到 120px → 文字换行 → 6×20px = +120px
  → 与总量 125px 完全吻合。

三、BUG 根因（我自己违反了自己定的纪律）
----------------------------------------------------------------
我嘴上说"只改视觉"，实际写了三类会改变盒模型的东西：

1. 【选择器误伤】给 `.navi ul.nav>li` 加 padding
   → 这个选择器同时命中了"分组标题 li"和"分隔线 li"，
     分组标题 51px → 97px（+46px），且和另一条规则重复叠加。

2. 【压缩宽度导致换行】给 `.navi` 加 padding、给菜单 <a> 加水平 margin
   → 二级菜单（nav-sub）本身缩进就深，再压 20px 就换行了。
   这是 +120px 的直接原因，也是你看到"侧栏变长、页面被顶下去"的主因。

3. 【新增边框 / BFC / 描边】
   - 给头像 img 加 border:2px → 顶栏 +19px
   - 给 .panel 加 overflow:hidden → 创建 BFC，阻止 margin 折叠 → 面板 +18px
   - 给 modal-header/footer 加 border 1px → 页面 +2px
   - 给按钮/panel 加 padding、改 font-size → 尺寸漂移

四、v3 修复：零几何变化原则（可验证）
----------------------------------------------------------------
  允许：color / background / background-image
        / border-color（只改颜色，绝不改宽度）
        / border-radius / box-shadow / font-family / font-weight
        / opacity / transition
  禁止：padding / margin / width / height / border-width
        / border（新增或删除）/ display / float / font-size / line-height

  关键手法：
  · 要描边 → 用 box-shadow:0 0 0 1px（画在盒外，不占空间）
  · 要分隔线 → 只改 border-*-color，保留原生宽度
  · 菜单"药丸"感 → 只用 border-radius + 背景色，绝不加 padding/margin
  · 面板标题色条 → ::before + position:absolute（不占文档流）
  · 头像描边 → box-shadow 环，不用 border
  · 绝不给二级菜单（.nav-sub）加任何宽度相关属性

五、修复后实测（同一套验证方法）
----------------------------------------------------------------
                            原版      v3主题     差异
  .app-header               226       226       0 ✓
  .app-aside                979       979       0 ✓
  .app-aside .navi          855       855       0 ✓
  .app-content              900       900       0 ✓
  标题条                    81        81        0 ✓
  .panel                    121       121       0 ✓
  .app-footer               51        51        0 ✓
  侧栏 li 总高              1055      1055      0 ✓
  页面总高                  1060      1060      0 ✓

  ★ 全部为 0。深色侧栏（bg-black）场景同样为 0，
    且菜单文字已同步改深色（不会出现白底白字）。

六、本版同步重做的范围
----------------------------------------------------------------
  assets/css/theme-admin.css    后台 63 页
  assets/css/theme-user.css     用户中心 41 页
  paypage/css/theme-pay.css     收银台 8 页（保留 rem+float+table 原生排版）
  template/<11套>/assets/css/theme.css   每套独立定制

  ★ 11 套前台模板各自独立：
    default / index1 / index2 / index3 / index4(Argon·BS4)
    / index5 / index6(主题色) / index7(BS4) / index8
    / index9(深蓝页脚) / index10
    按各自的导航、按钮、页脚、卡片类名单独写，不再是"一套硬套"。

七、部署与回滚
----------------------------------------------------------------
  部署：解压覆盖根目录（config.php 保留你自己的，别覆盖）
        → 重启 PHP / 清 OPcache → Ctrl+F5
  回滚：删掉各入口那一行 <link ... theme.css"> 即可瞬间还原
        （因为零几何变化，装上和拆掉页面布局完全一致）

  换主色：改各 CSS 顶部 :root 的 --brand 系列变量。

八、改动文件清单
----------------------------------------------------------------
  新增 CSS 14 个：
    assets/css/theme-admin.css
    assets/css/theme-user.css
    paypage/css/theme-pay.css
    template/{default,index1..index10}/assets/css/theme.css
  引用注入 22 处（每个文件 </head> 前一行）：
    admin/head.php
    user/head.php + 8 个独立页
    paypage/ 8 个页面
    template/default|index1 的 head.php，index2~index10 的 index.php
  未改动任何 PHP 逻辑、SQL、表单字段名、权限判断。


================================================================
九、功能二开：拉单「支付环境安全检查页」（新增）
================================================================
需求：用户拉单支付时，先显示检查页停留约 3 秒，
      逐条检测"支付环境 + IP"，通过后自动进入支付页。

【实现位置】includes/functions.php
  · submitTemplateRaw()   原跳转页（未改动，原样保留）
  · payEnvCheckItems()    服务端检查项计算
  · payEnvCheckPage()     检查页渲染
  · submitTemplate()      入口分流：开关关闭→原逻辑；开启→检查页

【为什么改这里】
  submitTemplate() 是「拉单后进入支付前」的统一出口：
    submit.php  → lib\api\Pay::submit()  → Payment::echoDefault()
    submit2.php → 收银台选完支付方式     → Payment::echoDefault()
  echoDefault 在 type=jump / type=html 且 submit=true 时都调用它。
  改这一个函数，submit 接口与收银台两条链路同时生效。

【检查项（服务端真实计算，非假动画）】
  1. 支付环境检测  识别 微信/支付宝/手机QQ/云闪付/移动端浏览器/电脑浏览器
  2. 网络地址校验  获取真实IP，页面脱敏显示为 112.96.*.*
  3. IP风险名单    查 pre_blacklist(type=1)，命中则拦截
  4. 今日支付频次  按 pay_iplimit 配置统计，超限则拦截
  5. 订单安全校验  校验订单号已创建

【交互】
  · 检查项逐条点亮（总时长均分），进度条同步
  · 全部通过后显示"X 秒后自动前往支付"倒计时
  · 倒计时结束自动执行原有跳转/提交代码
  · 页面同时出现"立即前往支付"按钮，可点击跳过等待
  · 任一检查项失败：红色提示 + 不跳转 + "返回上一页"按钮

【跳转兼容性（已实测）】
  原 submitTemplate 收到的 $html_text 有两类，均验证通过：
  ① <script>window.location.replace(...)</script>         → 已验证跳转成功
  ② <form> + <script>document.forms['x'].submit()</script> → 已验证 POST 发出
  实现方式：把原 HTML 以 PHP json_encode 内嵌为 JS 字符串
  （默认转义 / ，所以 </script> 会变成 <\/script>，不会截断脚本），
  到时间后用 DOM 注入 + 重建 <script> 执行，
  不使用 document.write（避免 Chrome 在慢网下拦截注入脚本）。

【后台开关】系统设置 → 风控检测 →「支付环境安全检查页」
  · pay_check_open   0关闭 / 1开启（默认关闭，不改变任何原有行为）
  · pay_check_second 停留秒数，1~30，建议 3
  配置保存走原有 ajax.php?act=set（foreach $_POST 自动落库），无需改动。

【安全性】
  · 开关默认关闭：未开启时 100% 走原代码，零影响
  · 检查项全部在服务端算，前端无法伪造绕过
  · 页面不输出任何密钥、商户号等敏感信息
  · IP 做了脱敏展示

【验证方式】Chromium 实渲染 4 个场景
  A jump 跳转      → 3 秒后自动跳转 ✅
  B form 提交      → POST 请求已发出 ✅
  C 点击按钮       → 立即跳转 ✅
  D IP黑名单       → 红色提示、不跳转 ✅


================================================================
十、v4 更新：浅蓝科技风配色 + 检查项增强 + 订单创建前置
================================================================

【1】配色改为浅蓝科技风（专业 / 集团感）
  主色渐变   #0ea5e9（天蓝） → #2563eb（科技蓝）
  浅色底     #e0f2fe
  页面背景   #f0f6fc
  分隔线     #dbeafe / #eaf4fd
  聚焦光环   rgba(14,165,233,.14)
  按钮光晕   rgba(14,165,233,.32)

  ★ 严格遵守"零几何变化"：本次只替换 color / border-color /
    box-shadow / border-radius，文字与框架结构完全未动。
    实测几何对比仍为全 0（顶栏/侧栏/内容区/面板/页脚/侧栏li总高/页面总高）。

  科技感细节（同样不占几何）：
  · 侧栏选中项新增 inset 3px 左侧色条
  · 后台顶部导航激活项新增 inset 2px 下边条
  · 顶栏/卡片阴影改为蓝调 rgba(14,165,233,.06~.10)
  · 涉及文件：theme-admin / theme-user / theme-pay
              + 11 套前台模板 + 检查页内嵌样式

【2】黑名单检查增强（用户要求：同时查 IP 和支付账号）
  后台位置：用户管理 → 支付黑名单管理（admin/blacklist.php）
  该表分两类：type=1 IP地址，type=0 支付账号

  · IP 风险名单：拉单时直接比对本次 IP
    （已支持有效期：过期后自动放行）
  · 支付账号风险：拉单时用户尚未付款、拿不到本次账号，
    因此回溯该 IP 近 30 天成功订单的 buyer 账号，
    逐个比对 type=0 黑名单做预判，命中即拦截。
  · 支付完成后的拦截由原有 checkBlockUser() 负责（已存在），
    并在 black_payact=2 时可自动退款。两层拦截互补。

【3】今日支付频次：后台在哪里看/设
  后台 → 系统设置 → 风控检测 →「限制每IP每天支付笔数」
  对应配置键 pay_iplimit，留空为不限制。
  检查页按此值统计当日已支付笔数，超限时拦截。

【4】订单创建前置（用户要求：通过才创建，不通过不创建订单号）
  原实现是在订单创建"之后"才走检查页，现改为前置：

  修改 includes/lib/api/Pay.php，在 INSERT 订单之前插入：
      if(!empty($conf['pay_check_open'])){
          payCheckBeforeCreate($queryArr, 'get'/'post', $pid, $out_trade_no);
      }

  流程：
    拉单请求 → 参数/商户校验 → ★环境检查页（此时未建单）
             → 检查通过 → 带一次性凭据 __check 重新发起
             → 校验凭据有效 → 放行 → INSERT 订单 → 进入支付

  凭据机制（防止直接绕过）：
  · payCheckCreateToken() 写入 pre_config，5 分钟有效
  · payCheckVerifyToken() 校验后立即删除（一次性消费）
  · GET 回跳：URL 追加 __check=token
  · POST 回跳：构造隐藏表单自动提交，兼容 POST 下单
  · 检查不通过：不生成凭据跳转，订单不会被创建

  ★ 因此现在是真正的"先检查、后建单"，
    被拦截的请求在 pre_order 表中不会留下任何记录。


================================================================
十一、v5 重排版（本次）：真正打乱版面，不只是换皮
================================================================
用户要求：打乱整个 UI 甚至功能页排版，在不影响功能的前提下。
故本次"允许改布局"，与 v3/v4 的"零几何变化"纪律不同。

【1】后台 admin/head.php 顶部导航：整体重写
  原结构：bootstrap navbar-fixed-top + .container + navbar-right 下拉
  新结构（.adm-* 全新类名，不与 bootstrap 冲突）：
    .adm-topbar         fixed 顶栏，高 60px，含品牌区/主菜单/右侧操作
      .adm-brand        渐变方块 logo + 中文名 + 英文副标题（分两行）
      .adm-nav          7 个主菜单横排（首页/收款订单/付款管理/商户管理/
                        支付接口/系统设置/其他功能）
        .adm-dropdown   hover 展开的卡片式下拉，每项带图标
      .adm-topbar-right 前台入口 + 退出按钮（红色描边）
      .adm-burger       窄屏汉堡按钮

  废弃：原 bootstrap navbar 高度体系
  新增：body.adm-body{padding-top:60px} 承载内容偏移

  ★ 功能零改动：37 个导航链接全部保留，checkIfActive() 逻辑原样保留，
    只是 class 名从 bootstrap 的 nav/navbar-nav 换成 adm-nav-item。
    实测 37 个链接目标全部存在（satf_transfer/mchrisk 为可选插件页，
    本来就有 class_exists 条件包裹，非缺失）。

【2】后台内容区：全宽化
  容器 max-width 1680px、左右 22px
  原 col-lg-9 center-block 居中 → 100% 宽度
  统计 list-group → flex 网格数据卡（每项 flex 1 1 260px）
  安全提示项独占整行（flex 1 1 100%）

【3】用户中心侧栏：200px → 240px，分组重做
  ★ 成对修改（这是关键，缺一就会错位）：
      @media(min-width:768px){
        .app-aside,.navbar-header{width:240px}
        .navbar-collapse,.app-content,.app-footer{margin-left:240px}
      }
    折叠态同步：240px ↔ 68px（两组都改）
    .app-aside-fixed .aside-wrap 宽度同步 239/67

  分组标题重做：小号大写字母 + 右侧渐变下划线（::after，flex:1）
  菜单项：padding 10px 16px，图标统一 18px 宽居中，flex 对齐
  选中态：inset 3px 左侧主色条
  二级菜单：缩进到 44px 对齐图标

  实测（1600 / 1280 两个宽度）：
    侧栏 240，内容区 x=248，无重叠 ✓
    折叠态 68，内容区 x=76 ✓
    顶栏 56px ✓

【4】顶栏加高
  原 50px → 56px，品牌区 padding 0 20px，头像 32px
  .app-header-fixed{padding-top:56px} 同步

【5】功能页重排（纯 CSS，未动任何 PHP）
  用户中心首页：
    统计卡 → 14px 圆角 + 蓝调阴影 + hover 上浮 3px
    隐藏原右上角无意义小三角
    数字圆形图标 → 主色渐变方块（46px，圆角 13px）
    数值 24px 加粗，内部改 flex 紧凑排布
    用户信息卡头部 → 主色渐变，头像 78px 圆形白边
    今日/昨日收入横条 → hover 淡蓝
  后台首页：
    统计 list-group → flex 网格（见上）
    管理员信息卡 → 头像 64px 白边，横向排布

【6】配色（延续 v4 浅蓝科技风）
  主色 #0ea5e9 → #2563eb 渐变
  页面底 #f0f6fc，卡片白底 + #dbeafe 描边 + 蓝调阴影

【7】验证
  PHP 语法：head.php / index.php / functions.php / Pay.php / user/*.php 全部 OK
  （admin/set.php 为解析器对原文件本就报错，非本次引入）
  浏览器实渲染：顶栏 60px fixed、7 菜单横排、hover 下拉 block、
                统计卡 flex 网格、侧栏 240/68 无重叠

【8】回滚
  v5 改动集中在 4 处，可单独回退：
    admin/head.php          → 还原原 navbar 结构即恢复旧后台顶栏
    assets/css/theme-admin.css 的【布局重排】段
    assets/css/theme-user.css  的【布局重排】段
    assets/css/theme-*.css     的【功能页重排】段
  前面 v4 的浅蓝配色与 v3 的安全检查页功能不受影响。
